function varargout = Software_CMaN_Ver1(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Software_CMaN_Ver1_OpeningFcn, ...
                   'gui_OutputFcn',  @Software_CMaN_Ver1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Software_CMaN_Ver1 is made visible.
function Software_CMaN_Ver1_OpeningFcn(hObject, eventdata, handles, varargin)
global ignorePeaks ignoreValleys Axes2OptionsList ComponentForProcess hat
% Functions List
%---------------


clear('ROIProcessed','FileNameAVI','FrameRate','FramesTotalNumberInVideo','FrameRate','Vx','Vy','d','r','s1','s2','time','InvertsignalCh','FilterVal',...
      'FrameNrProcessedStart', 'FrameNrProcessedEnd','SelectdDataIndicator','BaseLinDriftCorCh','FilterVal','InvertsignalCh','FWHMorElse',...
          'State_Level_Tolerances','RelaxationTimes','RelaxationStartTimes','RelaxationEndTimes','RelaxationTimesMean','RelaxationTimesSTD',...
             'RelaxationPeaksIndices','RelaxationPeaksAmplitudes','RelaxationPeaksAmplitudesSTD','RelaxationPeaksAmplitudesMean','ContractionTimes',...
                'ContractionStartTimes','ContractionEndTimes','ContractionTimesMean','ContractionTimesSTD','ContractionPeaksIndices',...
                    'ContractionPeaksAmplitudes','ContractionPeaksAmplitudesSTD','ContractionPeaksAmplitudesMean','BeatIntervalTimes','BeatIntervalTimesMean',...
                        'BeatIntervalTimesSTD','BeatingFrequency_BPM');  
clear('ignorePeaks','ignoreValleys');
clear xyloObj FileNameAVI FileNameMAT AVIfilesList MATfilesList im1

handles.output = hObject; clc
axes(handles.axes1); axis off; imshow(strcat(pwd,'\fns\noVideo2Display.png'));
set(handles.ShearXCheck,'value',1);
set(handles.ProcessOneFile,'enable','on','string','Process select video','BackgroundColor',[0.83  0.82 0.78]);
set(handles.FilterSlider,'value',1);
set(handles.selectAVICh,'value',0);
set(handles.SaveWithMeasure,'Value',1);
TableData = [[0 0 0 0 0 0]',[0 0 0 0 0 0]'];
set(handles.ParamTable,'data',TableData);
set(handles.editFolderName,'string',pwd);
cla(handles.axes2,'reset');            
axes(handles.axes2);%plot(sin(1:0.1:10)) ;
imshow(strcat(pwd,'\fns\thumbnailImg.png'));
set(handles.axes2,'xtick',[])
set(handles.AutoFcheck,'Value',1);
handles.axes2.YAxisLocation = 'left'; 
ComponentForProcess='s1';
Axes2OptionsList=1;
ignorePeaks=0; ignoreValleys=0;
set(handles.PeakWidthMeanSlider1,'Max',2);set(handles.PeakWidthMeanSlider1,'Min',0);
set(handles.PeakWidthMeanSlider1, 'SliderStep', [1/40 1/40]); set(handles.PeakWidthMeanSlider1,'value',0.5);
set(handles.PeakWidthMeanSlider2,'Max',2);set(handles.PeakWidthMeanSlider2,'Min',0);
set(handles.PeakWidthMeanSlider2, 'SliderStep', [1/40 1/40]); set(handles.PeakWidthMeanSlider2,'value',0.5);
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = Software_CMaN_Ver1_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Browsefolder.
function Browsefolder_Callback(hObject, eventdata, handles)
% hObject    handle to Browsefolder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global PathName FileNameAVI AVIfilesList MATfilesList xyloObj ImrectCreateROIst ProcessOrNotState FrameRate FileNameMAT   im1 

axes(handles.axes1); axis off;
ProcessOrNotState = 1;
set(handles.selectAVICh,'value',0);
set(handles.selectMatCh,'value',0);
set(handles.ProcessOneFile,'enable','on');
set(handles.ProcessAll_files,'enable','on');
    handles.SelectFilesListBox.String = [];
           %set(handles.SelectFilesListBox,'string',{AVIfilesList.name});   
try 
       PathName = uigetdir(pwd,'Select Folder');
    if PathName==0
       PathName=pwd;
    end
end
set(handles.editFolderName,'string',PathName);


% --- Executes on button press in selectAVICh.
function selectAVICh_Callback(hObject, eventdata, handles)
global AVIfilesList FileNameAVI FileNameMAT MATfilesList PathName ImrectCreateROIst xyloObj FrameRate posNr ROIbox
global ROIProcessed FilterVal
ROIbox=handles.userROIbox;
set(handles.ProcessOneFile,'enable','on');
set(handles.ProcessAll_files,'enable','on');
                % FilterVal=ceil(get(handles.FilterSlider,'Value')); if FilterVal ==0, FilterVal=1; end    

if get(handles.selectAVICh,'Value')==1
    set(handles.selectMatCh,'value',0);
    try
        PathName=get(handles.editFolderName,'string');
           AVIfilesList = dir(strcat(PathName,'\*.avi'));
           MATfilesList = dir(strcat(PathName,'\*.mat'));   
           set(handles.SelectFilesListBox,'string',{AVIfilesList.name});   
           %get(handles.SelectFilesListBox,'Value');
           set(handles.SelectFilesListBox,'Value',1);   
           FileNameAVI=AVIfilesList(1).name; 
    
           xyloObj=VideoReader(strcat(PathName,'/',FileNameAVI));
           FrameRate=xyloObj.FrameRate;
           
           RefFrameNr=1;
                xyloObj.CurrentTime=(RefFrameNr-1)/FrameRate;
                try
                    im1 = im2double(rgb2gray(readFrame(xyloObj)));
                catch
                    im1 = im2double(readFrame(xyloObj));
                end
                axes(handles.axes1); axis off; imshow(im1) 

 %          ImrectCreateROIst = imrect(handles.axes1, ROIst); setColor(ImrectCreateROIst,'green');  
           %ImrectCreateROIst = images.roi.Rectangle(handles.axes1,'Position',ROIst,'FaceAlpha',0,'Color','g');
           %ROICurrent=addlistener(ImrectCreateROIst,'MovingROI',@allevents)
           ROIst=[0.25*xyloObj.Width 0.25*xyloObj.Height xyloObj.Width/2 xyloObj.Height/2];
           ImrectCreateROIst = drawrectangle(handles.axes1,'Position',ROIst,'Color','g', 'FaceAlpha',0);
           ROIStr=mat2str(round(ROIst));
            set(handles.userROIbox,'string',ROIStr(2:end-1));
           ROIProcessed=addlistener(ImrectCreateROIst,'MovingROI',@allevents);

           %set(handles.messageText,'string',msgStr,'Fontsize',13,'FontWeight','bold','ForegroundColor','b');
    catch
           axes(handles.axes1); axis off; 
           imshow(strcat(pwd,'\fns\noVideo2DisplayORCodecNotSupported.png'));
    end 
else    
    handles.SelectFilesListBox.String = [];
end  

try
    AVI_string_For_CorrespondingMAT_search=AVIfilesList(1).name(1:end-4);
    StringComparisionResultVec=[];
    for n=1:length(MATfilesList)
        MAT_strings= MATfilesList(n).name;
        StringComparisionResult=[strfind(MAT_strings, AVI_string_For_CorrespondingMAT_search)];
    if isempty(StringComparisionResult)==1, StringComparisionResult=nan;    end
        StringComparisionResultVec=[StringComparisionResultVec;StringComparisionResult]; 
    end
    NonNanIndices=find(~isnan(StringComparisionResultVec));
    FileNameMAT=MATfilesList(NonNanIndices(1)).name; % First non nan el
    
    cla(handles.axes2,'reset');            
    load(strcat(PathName,'\',FileNameMAT));
    axes(handles.axes2);handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom'; plot(time,eval(SelectdDataIndicator));axis on; grid on
    handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom';
    TableData = [[RelaxationTimesMean RelaxationPeaksAmplitudesMean ContractionTimesMean  ContractionPeaksAmplitudesMean BeatIntervalTimesMean BeatingFrequency_BPM]',...
    [RelaxationTimesSTD RelaxationPeaksAmplitudesSTD ContractionTimesSTD ContractionPeaksAmplitudesSTD BeatIntervalTimesSTD nan]'];
    set(handles.ParamTable,'data',TableData);           
end
set(handles.MeasureBeatParameters,'enable','off');
posNr=1;


% --- Executes on button press in selectMatCh.
function selectMatCh_Callback(hObject, eventdata, handles)
global AVIfilesList MATfilesList xyloObj FileNameMAT FileNameAVI PathName FrameRate ImrectCreateROIst ComponentForProcess posNr
global AutoFcheckSt FilterVal
set(handles.ProcessOneFile,'enable','off');
set(handles.ProcessAll_files,'enable','off');
%FilterVal
if get(handles.selectMatCh,'Value')==1
                 %FilterVal=ceil(get(handles.FilterSlider,'Value')); if FilterVal ==0, FilterVal=1; end    
         set(handles.SelectFilesListBox,'enable','on');    
         set(handles.selectAVICh,'Value',0);
                  
                  try
                      PathName=get(handles.editFolderName,'string');
                      AVIfilesList = dir(strcat(PathName,'\*.avi'));
                      MATfilesList = dir(strcat(PathName,'\*.mat'));                     
                      set(handles.SelectFilesListBox,'string',{MATfilesList.name});   
                      %get(handles.SelectFilesListBox,'Value');
                      set(handles.SelectFilesListBox,'Value',1);   
                      FileNameMAT=MATfilesList(1).name;            
                  end
                  set(handles.MeasureBeatParameters,'enable','on');
else
    
    handles.SelectFilesListBox.String = [];
    set(handles.MeasureBeatParameters,'enable','off');

end           
     cla(handles.axes1,'reset'); cla(handles.axes2,'reset');
     try
         load(strcat(PathName,'\',FileNameMAT));
         axes(handles.axes1); axis off;  imshow(FirstFrameWithROI);         
            if get(handles.VxCheck,'Value')==1
                SelectdData=Vx; 
                SelectdDataIndicator='Vx';
            elseif get(handles.VyCheck,'Value')==1
                SelectdData=Vy; 
                SelectdDataIndicator='Vy';
            elseif get(handles.DilationCheck,'Value')==1
                SelectdData=d; 
                SelectdDataIndicator='d';
            elseif get(handles.RotationCheck,'Value')==1
                SelectdData=r; 
                SelectdDataIndicator='r';
            elseif get(handles.ShearXCheck,'Value')==1
                SelectdData=s1; 
                SelectdDataIndicator='s1';
            elseif get(handles.ShearDiagCheck,'Value')==1
                SelectdData=s2; 
                SelectdDataIndicator='s2';
            end   
        ComponentForProcess=SelectdDataIndicator;
   try
    AutoFcheckSt=get(handles.AutoFcheck,'Value');
   if AutoFcheckSt ==1
        [SNRi,Fl6Str,AutoComp]=AutoCompSelect(Vx,Vy,d,r,s1,s2); 
        cla(handles.axes2,'reset');  
        
        axes(handles.axes2); plot(time,AutoComp);handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom';axis on; grid on            
        [ProcessedData]=PostProcess(BaseLinDriftCorCh,InvertsignalCh,FilterVal,AutoComp);
   for ii=1:6       
       set(eval(['handles.',Fl6Str{SNRi(ii)}]),'Value',0);
       if ii==6
        set(eval(['handles.',Fl6Str{SNRi(6)}]),'Value',1);
       end
   end 
   
   else
       [ProcessedData]=PostProcess(BaseLinDriftCorCh,InvertsignalCh,FilterVal,eval(ComponentForProcess));
   end
   end
       
 axes(handles.axes2);handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom'; 
 plot(time,ProcessedData);axis on; grid on
 handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom';
        TableData = [[RelaxationTimesMean RelaxationPeaksAmplitudesMean ContractionTimesMean  ContractionPeaksAmplitudesMean BeatIntervalTimesMean BeatingFrequency_BPM]',...
        [RelaxationTimesSTD RelaxationPeaksAmplitudesSTD ContractionTimesSTD ContractionPeaksAmplitudesSTD BeatIntervalTimesSTD nan]'];
        set(handles.ParamTable,'data',TableData);   
     catch
     axes(handles.axes1); axis off;  
     imshow(strcat(pwd,'\fns\noMatFiles2Display.png'));


     end
posNr=1;

     % --- Executes on selection change in Axes2OptionsList.
function Axes2OptionsList_Callback(hObject, eventdata, handles)
global Axes2OptionsList
Axes2OptionsList=double(get(handles.Axes2OptionsList,'Value'));

     
% --- Executes on selection change in SelectFilesListBox.
function SelectFilesListBox_Callback(hObject, eventdata, handles)

global AVIfilesList MATfilesList PathName FileNameAVI FileNameMAT xyloObj FilterVal ImrectCreateROIst ROIProcessed FrameRate Axes2OptionsList SelectdDataIndicator ComponentForProcess 
global BaseLinDriftCorCh InvertsignalCh
global AutoFcheckSt Final_plot

BaseLinDriftCorCh=get(handles.BaseLinDriftCorCh,'Value');
InvertsignalCh=get(handles.InvertsignalCh,'Value');

addpath(strcat(pwd,'\fns'));

 
try
%ROIst=getPosition(ImrectCreateROIst);
end
if get(handles.selectAVICh,'Value')==1
    %clear Vx Vy d r s1 s2 time    
    try
       FileNameAVI=AVIfilesList(double(get(handles.SelectFilesListBox,'Value'))).name;
        RefFrameNr=1;
        xyloObj=VideoReader(strcat(PathName,'/',FileNameAVI));
            FrameRate=xyloObj.FrameRate;
            xyloObj.CurrentTime=(RefFrameNr-1)/FrameRate;
            
            try
                im1 = im2double(rgb2gray(readFrame(xyloObj)));
            catch
                im1 = im2double(readFrame(xyloObj));
            end
                axes(handles.axes1);imshow(im1);   
                
                
        test= (get(handles.userROIbox,'String'));
        num = textscan(test, '%f', 'Delimiter',',' );
        ROIProcessed = permute(num{1},[2,1]);
            [ROIProcessed]= minROIadjuster (ROIProcessed, xyloObj.Width, xyloObj.Height);
   
        try
           delete(ImrectCreateROIst);
           ImrectCreateROIst = drawrectangle(handles.axes1,'Position',ROIProcessed,'Color','g', 'FaceAlpha',0);
           ROIStr=mat2str(round(ROIProcessed));
           set(handles.userROIbox,'string',ROIStr(2:end-1));
         end            
        ROICurrent=addlistener(ImrectCreateROIst,'MovingROI',@allevents);
%                        ROIStr=mat2str(round(ROICurrent));
%             set(handles.userROIbox,'string',ROIStr(2:end-1));
            
            
%         %ROIst=[0.25*xyloObj.Width 0.25*xyloObj.Height xyloObj.Width/2 xyloObj.Height/2];
%             test= (get(handles.userROIbox,'String'));
%             num = textscan(test, '%f', 'Delimiter',',' );
%             ROIProcessed = permute(num{1},[2,1]);       
%             ImrectCreateROIst = drawrectangle(handles.axes1,'Position',ROIProcessed,'Color','g', 'FaceAlpha',0);
%             %ROICurrent=addlistener(ImrectCreateROIst,'MovingROI',@allevents)
%            
%             ROIStr=mat2str(round(ROICurrent));
%             set(handles.userROIbox,'string',ROIStr(2:end-1));
            
        %ImrectCreateROIst = imrect(handles.axes1, ROIst); setColor(ImrectCreateROIst,'green');
        %ROIProcessed=getPosition(ImrectCreateROIst); 
        %MATfilesList
        
        try
                 cla(handles.axes2,'reset') 
                 ListBoxCurrentPosNr=double(get(handles.SelectFilesListBox,'Value'));
                 
                    STRFINDforMAT=strfind({MATfilesList.name}, FileNameAVI(1:end-4));
                    indxForCorrMAT=find(~cellfun(@isempty,STRFINDforMAT));
                 FileNameMAT=MATfilesList(indxForCorrMAT).name;
                 load(strcat(PathName,'\',FileNameMAT));
                 FilterVal=ceil(get(handles.FilterSlider,'Value')); if FilterVal ==0, FilterVal=1; end;    
                 axes(handles.axes2); handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom'; 
                 
                    
   try
       if AutoFcheckSt ==1

    [SNRi,Fl6Str,AutoComp]=AutoCompSelect(Vx,Vy,d,r,s1,s2);
    cla(handles.axes2,'reset');  
    axes(handles.axes2); plot(time,AutoComp);handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom';axis on; grid on            
    [ProcessedData]=PostProcess(BaseLinDriftCorCh,InvertsignalCh,FilterVal,AutoComp);

   for ii=1:6       
       set(eval(['handles.',Fl6Str{SNRi(ii)}]),'Value',0);
       if ii==6
        set(eval(['handles.',Fl6Str{SNRi(6)}]),'Value',1);
       end
   end 
   
   else
    [ProcessedData]=PostProcess(BaseLinDriftCorCh,InvertsignalCh,FilterVal,eval(ComponentForProcess));
   end
   end
                     
                     
                     plot(time,ProcessedData);axis on; grid on
                 
                 handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom';
                 TableData = [[RelaxationTimesMean RelaxationPeaksAmplitudesMean ContractionTimesMean  ContractionPeaksAmplitudesMean BeatIntervalTimesMean BeatingFrequency_BPM]',...
                 [RelaxationTimesSTD RelaxationPeaksAmplitudesSTD ContractionTimesSTD ContractionPeaksAmplitudesSTD BeatIntervalTimesSTD nan]'];
                 set(handles.ParamTable,'data',TableData);
        catch         

        end
    catch 
        axes(handles.axes1); axis off; 
        imshow(strcat(pwd,'\fns\noVideo2DisplayORCodecNotSupported.png')); 
    end

    if get(handles.selectMatCh,'Value')==1
       FileNameMAT=MATfilesList(double(get(handles.SelectFilesListBox,'Value'))).name;
    end
end      

if get(handles.selectMatCh,'Value')==1
     FileNameMAT=MATfilesList(double(get(handles.SelectFilesListBox,'Value'))).name;
     load(strcat(PathName,'\',FileNameMAT));
     FilterVal=ceil(get(handles.FilterSlider,'Value')); if FilterVal ==0, FilterVal=1; end;    
        cla(handles.axes1,'reset'); cla(handles.axes2,'reset');  
        axes(handles.axes1); axis off;  imshow(FirstFrameWithROI);
        if Axes2OptionsList==1
        axes(handles.axes2); 
                            BaseLinDriftCorCh=get(handles.BaseLinDriftCorCh,'Value');
                            InvertsignalCh=get(handles.InvertsignalCh,'Value');
                             AutoFcheckSt=get(handles.AutoFcheck,'Value');
   if AutoFcheckSt ==1
   
    [SNRi,Fl6Str,AutoComp]=AutoCompSelect(Vx,Vy,d,r,s1,s2);
    cla(handles.axes2,'reset');  
    axes(handles.axes2); plot(time,AutoComp);handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom';axis on; grid on            
    [ProcessedData]=PostProcess(BaseLinDriftCorCh,InvertsignalCh,FilterVal,AutoComp);

   for ii=1:6       
       set(eval(['handles.',Fl6Str{SNRi(ii)}]),'Value',0);
       if ii==6
        set(eval(['handles.',Fl6Str{SNRi(6)}]),'Value',1);
       end
   end 
   
   else
     [ProcessedData]=PostProcess(BaseLinDriftCorCh,InvertsignalCh,FilterVal,eval(ComponentForProcess));
   end

        plot(time,ProcessedData);axis on; grid on
        handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom';
        elseif Axes2OptionsList==2
            try
            axes(handles.axes2); axis off; imshow(Final_plot);
%         axes(handles.axes2); axis off; imshow(FirstFrameWithROI);
        
            end
        end
        TableData = [[RelaxationTimesMean RelaxationPeaksAmplitudesMean ContractionTimesMean  ContractionPeaksAmplitudesMean BeatIntervalTimesMean BeatingFrequency_BPM]',...
        [RelaxationTimesSTD RelaxationPeaksAmplitudesSTD ContractionTimesSTD ContractionPeaksAmplitudesSTD BeatIntervalTimesSTD nan]'];
        set(handles.ParamTable,'data',TableData);        
end
try
    ListBoxCurrentPosNr=double(get(handles.SelectFilesListBox,'Value'));% To handle if as many MAT files as of AVIs are not in the directory             
    FileNameMAT=MATfilesList(double(ListBoxCurrentPosNr)).name;
end
   


% --- Executes during object creation, after setting all properties.
function SelectFilesListBox_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Play_video.
function Play_video_Callback(hObject, eventdata, handles)
global xyloObj PathName FileNameAVI AVIfilesList ImrectCreateROIst FrameRate ROIProcessed
    ROI=[0 0 xyloObj.Width xyloObj.Height];

if exist('MoviePlayer'), close('MoviePlayer'), end

try
   FileNameAVI=AVIfilesList(double(get(handles.SelectFilesListBox,'Value'))).name;
   RefFrameNr=1;
    xyloObj=VideoReader(strcat(PathName,'/',FileNameAVI));
    axes(handles.axes1); axis off; 
        FrameRate=xyloObj.FrameRate;
        xyloObj.CurrentTime=(RefFrameNr-1)/FrameRate;
                  im1 = readFrame(xyloObj); 
                 im1=im2double(im1(:,:,1)); imshow(im1)             
  
           %ROIst=[0.25*xyloObj.Width 0.25*xyloObj.Height xyloObj.Width/2 xyloObj.Height/2];
           ImrectCreateROIst = drawrectangle(handles.axes1,'Position',ROIProcessed,'Color','g', 'FaceAlpha',0);
           ROICurrent=addlistener(ImrectCreateROIst,'MovingROI',@allevents);


   MoviePlayer=implay(strcat(PathName,'/',FileNameAVI));
catch 
    axes(handles.axes1); axis off; 
    imshow(strcat(pwd,'\fns\noVideo2DisplayORCodecNotSupported.png'));  
end


% --- Executes on button press in ProcessOneFile.
function ProcessOneFile_Callback(hObject, eventdata, handles)
global xyloObj PathName FileNameAVI ImrectCreateROIst ProcessOrNotState Vx Vy d r s1 s2 time InvertsignalCh BaseLinDriftCorCh FilterVal FrameNrProcessedStart FrameNrProcessedEnd
global ProcessedData ComponentForProcess SelectdDataIndicator FrameRate FirstFrameWithROI Axes2OptionsList FramesTotalNumberInVideo MeasArea MoveCenterRect MoveCenterRectAffine ROIProcessed ImrectCreateROIst
global Line1ForMovCent Line2ForMovCent
addpath(strcat(pwd,'\fns'));
try
    delete(MoveCenterRect);
    delete(MeasArea);
end

try
    delete(MoveCenterRectAffine);
end

try

    
        test= (get(handles.userROIbox,'String'));
        num = textscan(test, '%f', 'Delimiter',',' );
        ROIProcessed = permute(num{1},[2,1]);
            [ROIProcessed]= minROIadjuster (ROIProcessed, xyloObj.Width, xyloObj.Height);
        try
           delete(ImrectCreateROIst);
           ImrectCreateROIst = drawrectangle(handles.axes1,'Position',ROIProcessed,'Color','g', 'FaceAlpha',0);
           ROIStr=mat2str(round(ROIProcessed));
           set(handles.userROIbox,'string',ROIStr(2:end-1));
         end            
        ROICurrent=addlistener(ImrectCreateROIst,'MovingROI',@allevents);
        
      
        TotalFrames = xyloObj.FrameRate*xyloObj.Duration;
        TotalFrames=round(TotalFrames);
        VidLengthStaPercent = str2double(get(handles.VidLengthStaPercent,'String'));
            FrameNrProcessedStart=round(TotalFrames*VidLengthStaPercent/100);
                        if FrameNrProcessedStart==0
                            FrameNrProcessedStart=1;
                        end                      
        VidLengthEndPercent = str2double(get(handles.VidLengthEndPercent,'String'));
            FrameNrProcessedEnd=round(TotalFrames*VidLengthEndPercent/100);
         
   clear flow; 
            if get(handles.VxCheck,'Value')==1
                SelectdDataIndicator='Vx';
            elseif get(handles.VyCheck,'Value')==1
                SelectdDataIndicator='Vy';
            elseif get(handles.DilationCheck,'Value')==1
                SelectdDataIndicator='d';
            elseif get(handles.RotationCheck,'Value')==1
                SelectdDataIndicator='r';
            elseif get(handles.ShearXCheck,'Value')==1
                SelectdDataIndicator='s1';
            elseif get(handles.ShearDiagCheck,'Value')==1
                SelectdDataIndicator='s2';
            end 
       Vx=zeros(TotalFrames,1);
       Vy=zeros(TotalFrames,1);
        d=zeros(TotalFrames,1);
        r=zeros(TotalFrames,1);
       s1=zeros(TotalFrames,1);
       s2=zeros(TotalFrames,1);
       MovCentFullVideo=[];
       MovCentFullVideoVy=[];
          
    vidWidth = round(ROIProcessed(3))+1;
    vidHeight = round(ROIProcessed(4))+1;
    mov = struct('cdata',zeros(vidHeight,vidWidth,3,'uint8'),'colormap',[]);        
    set(handles.ProcessOneFile,'enable','off','string','Processing..','BackgroundColor',[0.83  0.82 0.78]);
    set(handles.ProcessStop,'enable','on','string','Stop Process','BackgroundColor',[0.83  0.82 0.78]); 

    PerVec=linspace(1,100,length(FrameNrProcessedStart:FrameNrProcessedEnd-1));
            FrameRate=xyloObj.FrameRate;
            
tic
if get(handles.MovCentTextureDet,'Value')==1
    % Accordign to Heimo's idea
    xyloObj.CurrentTime=2.201;
    vidFrame0 = readFrame(xyloObj); 
    vidFrame=im2double(imcrop(vidFrame0(:,:,1),ROIProcessed));    
      
    [TextureCentX, TextureCentY]= MovementCenter_texture(vidFrame,ROIProcessed);
       MoveCenterRect = imrect(handles.axes1, [TextureCentX-1, TextureCentY-1,2 2]); setColor(MoveCenterRect,'red');         
      

    PixSiz=75;
  
    ROITextureCenter=[TextureCentX-PixSiz/2, TextureCentY-PixSiz/2,PixSiz,PixSiz];
    ROITextureCenter=round(ROITextureCenter);
    MeasArea = imrect(handles.axes1, ROITextureCenter); setColor(MeasArea,[0.49 0.18 0.56]); % setColor(MeasArea,'blue');
    % Accordign to Heimo's idea
else
    ROITextureCenter=[];
end

        if get(handles.MovCentDet,'Value')==1
            try

                 Line1pos2=getPosition(Line1ForMovCent);
                 Line2pos2=getPosition(Line2ForMovCent);
                 FrameNrProcessedStart=round(FrameRate*Line1pos2(1));
                        if FrameNrProcessedStart==0
                            FrameNrProcessedStart=1;
                        end 
                 FrameNrProcessedEnd=round(FrameRate*Line2pos2(1));
                 PerVec=linspace(1,100,length(FrameNrProcessedStart:FrameNrProcessedEnd-1));

            end
        end


   for i=FrameNrProcessedStart:FrameNrProcessedEnd-1
       if i==FrameNrProcessedStart
            xyloObj.CurrentTime=(i-1)/FrameRate;            
%             im1 = readFrame(xyloObj);         
            im1 = readFrame(xyloObj,'native');
            try
                  im1=im2double(imcrop(im1(:,:,1),ROIProcessed));          
            catch
                  im1=im1.cdata;
                  im1=im2double(imcrop(im1(:,:,1),ROIProcessed));  
            end            
       end       
   try
            xyloObj.CurrentTime=((i+1)-1)/FrameRate;
%             im2 = readFrame(xyloObj); 
              im2 = readFrame(xyloObj,'native');            
            try
                  im2=im2double(imcrop(im2(:,:,1),ROIProcessed));          
            catch
                  im2=im2.cdata;
                  im2=im2double(imcrop(im2(:,:,1),ROIProcessed));  
            end            

   end
  
        af = affine_flow('image1', im1, 'image2', im2, ...
            'sigmaXY', 12, 'sampleStep',12);
 
        af = af.findFlow; flow = af.flowStruct;   
        Vx(i,:)=flow.vx0;
        Vy(i,:)=flow.vy0;
        d(i,:)=flow.d;
        r(i,:)=flow.r;
        s1(i,:)=flow.s1;
        s2(i,:)=flow.s2;
         if get(handles.MovCentDet,'Value')==1
            
            try
                 Line1pos2=getPosition(Line1ForMovCent);
                 Line2pos2=getPosition(Line2ForMovCent);
            end
            
            
            
            try
                    delete(MoveCenterRectAffine1);
                    delete(MoveCenterRectAffine2);
                    %pause(0.1)
            end
          
                  [AFOFMovCentreOut,spR,spC,AFOFVy,IndicesFull]=MovementCenter_affine(im1,im2,ROIProcessed);   
                  [MovCentFullVideo]=[MovCentFullVideo; AFOFMovCentreOut];
                  
                  MovCentFullVideoVy=[MovCentFullVideoVy AFOFVy];
                  
                  SNR=[];
                  MAx=[];
                  for ii=1:16
%                         figure(10),
%                         subplot(4,4,ii)
                        sig=MovCentFullVideoVy(ii,:);
                        %plot(sig), hold on, %axis([0 1800 -4 4])
                        %pause(0.5)
                        %title(num2str(k))
                        sig2=medfilt1(sig,4);
                        SNR=[SNR; std(abs(sig2))];
                        MAx=[MAx; max((sig2))];
        if ProcessOrNotState == 0
            break
        end    
                  end
                  
                  
                  [MaxSNR,INdMaxSNR]=max(SNR);

                  try
                    MovCentFullVideoAvg=mode(MovCentFullVideo);  
                  catch
                    MovCentFullVideoAvg=mean(MovCentFullVideo);  
                  end
                  
%                    MovCentFullVideoAvg=max(MovCentFullVideo);  

       
          if i==FrameNrProcessedEnd-1
              
              if SelectdDataIndicator=='Vx'
                  xInd=2;  Yind=3;
              elseif SelectdDataIndicator=='Vy'
                  xInd=5;  Yind=6;
              elseif SelectdDataIndicator=='d'
                  xInd=8;  Yind=9;
              elseif SelectdDataIndicator=='r'
                  xInd=11;  Yind=12;
              elseif SelectdDataIndicator=='s1'
                  xInd=14;  Yind=15;
              elseif SelectdDataIndicator=='s2'
                  xInd=17;  Yind=18;
              end  
%                ExactX=MovCentFullVideoAvg(xInd)+round(ROIProcessed(1));
%                ExactY=MovCentFullVideoAvg(Yind)+round(ROIProcessed(2));
                    %        INdMaxSNR
               ExactX=IndicesFull(INdMaxSNR,1)+round(ROIProcessed(1));
               ExactY=IndicesFull(INdMaxSNR,2)+round(ROIProcessed(2));
               
                   ROIMoveCenter=[ExactX, ExactY, spC, spR];
                   ROIMoveCenter=round(ROIMoveCenter);
                   
                   MoveCenterRectAffine = imrect(handles.axes1,ROIMoveCenter); setColor(MoveCenterRectAffine,'blue');% setColor(MoveCenterRectAffine2,[0.49 0.18 0.56]);                   
                   
          end
        else
          ROIMoveCenter=[];  
        end
        
           
    im1=im2;  
               
        PercentProcessed = PerVec(i-min(FrameNrProcessedStart:FrameNrProcessedEnd)+1);
%            set(handles.messageText,'string',strcat('Processing: ',sprintf('%1.2f',PercentProcessed) ,' %'),'Fontsize',13,'FontWeight','bold','ForegroundColor','b');
            set(handles.messageText,'string',strcat(sprintf('%1.2f',PercentProcessed) ,' %'),'Fontsize',30,'FontWeight','bold','ForegroundColor','b');
         
        if ProcessOrNotState == 0
            break
        end    
       
   end  

toc
 
%            FirstFrameWithROI=getframe(handles.axes1); 
%            FirstFrameWithROI=FirstFrameWithROI.cdata;% First frame with ROI to save
%            %figure,imshow(FirstFrameWithROI)
           
           set(gcf,'paperpositionmode','auto');           
           %saveas(gcf,strcat(pwd,'\fns\PrintGUI.png'));
           %[X, Map] = frame2im(F);
           %FirstFrameWithROI=frame2im(getframe(gcf));
           FirstFrameWithROI=frame2im(getframe(handles.axes1)); 

        Vx=Vx-mean(Vx);% seting signal mean position to zero
        Vy=Vy-mean(Vy);
         d=d-mean(d);
        r=r-mean(r);
        s1=s1-mean(s1);
        s2=s2-mean(s2);

        
        %time=linspace(0,xyloObj.Duration, TotalFrames);       
   %length(time)
        Vx=medfilt1(Vx,4);% to avoid initial or end large transiets if any
        Vy=medfilt1(Vy,4);
         d=medfilt1(d,4);
        r=medfilt1(r,4);
        s1=medfilt1(s1,4);
        s2=medfilt1(s2,4);
        time=linspace(0,xyloObj.Duration, TotalFrames); 
        length(FrameNrProcessedStart:FrameNrProcessedEnd);
        length(xyloObj.Duration);
%    %------------------plotting----------------------------------
%   axes(handles.axes2); %plot(time,Vx);handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom'; axis on; grid on; 
%   text(mean(get(gca,'XLim')),mean(get(gca,'YLim')),'Updating plots','Color','red','FontSize',20);
%   %  pause(2)
%   plot(time,eval(SelectdDataIndicator)); handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom'; axis on; grid on; 
%    
% 
%    %------------------plotting---------------------------------^
   

 AutoFcheckSt=get(handles.AutoFcheck,'Value');
   if AutoFcheckSt ==1
    [SNRi,Fl6Str,AutoComp]=AutoCompSelect(Vx,Vy,d,r,s1,s2);
    cla(handles.axes2,'reset');  
    axes(handles.axes2); 
    text(mean(get(gca,'XLim')),mean(get(gca,'YLim')),'Updating plots','Color','red','FontSize',20);
    plot(time,AutoComp);handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom';axis on; grid on            
   
   for ii=1:6       
       set(eval(['handles.',Fl6Str{SNRi(ii)}]),'Value',0);
       if ii==6
        set(eval(['handles.',Fl6Str{SNRi(6)}]),'Value',1);
       end
   end 
   
   else
            if get(handles.VxCheck,'Value')==1
                SelectdData=Vx; 
                SelectdDataIndicator='Vx';
            elseif get(handles.VyCheck,'Value')==1
                SelectdData=Vy; 
                SelectdDataIndicator='Vy';
            elseif get(handles.DilationCheck,'Value')==1
                SelectdData=d; 
                SelectdDataIndicator='d';
            elseif get(handles.RotationCheck,'Value')==1
                SelectdData=r; 
                SelectdDataIndicator='r';
            elseif get(handles.ShearXCheck,'Value')==1
                SelectdData=s1; 
                SelectdDataIndicator='s1';
            elseif get(handles.ShearDiagCheck,'Value')==1
                SelectdData=s2; 
                SelectdDataIndicator='s2';
            end   
    ComponentForProcess=SelectdDataIndicator;
    cla(handles.axes2,'reset');  
    axes(handles.axes2); 
    text(mean(get(gca,'XLim')),mean(get(gca,'YLim')),'Updating plots','Color','red','FontSize',20);
    plot(time,SelectdData);handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom';axis on; grid on
       
   end
  
   



   
  if  ProcessOrNotState==0
           %set(handles.messageText,'string','Processing aborted','Fontsize',13,'FontWeight','bold','ForegroundColor','k');
  else
      %set(handles.messageText,'string','Processing completed | ready for analysis','Fontsize',13,'FontWeight','bold','ForegroundColor','b');
  end
      ProcessOrNotState = 1;   
    set(handles.ProcessOneFile,'enable','on','string','Process select video','BackgroundColor',[0.83  0.82 0.78]);
    set(handles.ProcessStop,'enable','off','string','Stop Process','BackgroundColor',[0.83  0.82 0.78]);
    
  catch
    %set(handles.messageText,'string','No data available. Process AVI file(s) first/choose MAT files for postprocessing','Fontsize',13,'FontWeight','bold','ForegroundColor','b');
  end

InvertsignalCh=0; BaseLinDriftCorCh=0; FilterVal=1; set(handles.FilterSlider,'value',FilterVal);
ProcessedData=0; % indicator for measurement data selection
ComponentForProcess='s1';
%SelectdDataIndicator='s1';
%SelectdDataIndicator=[];
Axes2OptionsList=1;
FramesTotalNumberInVideo=TotalFrames;
FileNameMAT=[]; 

if exist('ROIMoveCenter')==1
    ROIMoveCenter=ROIMoveCenter; 
else
    ROIMoveCenter=[]; 
end

if exist('ROITextureCenter')==1
    ROITextureCenter=ROITextureCenter; 
else
    ROITextureCenter=[]; 
end


FWHMorElse=[]; State_Level_Tolerances=[]; RelaxationTimes=[];RelaxationStartTimes=[];RelaxationEndTimes=[]; RelaxationTimesMean=[]; RelaxationTimesSTD=[];
  RelaxationPeaksIndices=[]; RelaxationPeaksAmplitudes=[];RelaxationPeaksAmplitudesSTD=[]; RelaxationPeaksAmplitudesMean=[]; ContractionTimes=[]; ContractionStartTimes=[];
  ContractionEndTimes=[]; ContractionTimesMean=[]; ContractionTimesSTD=[]; ContractionPeaksIndices=[]; ContractionPeaksAmplitudes=[]; ContractionPeaksAmplitudesSTD=[];
  ContractionPeaksAmplitudesMean=[];BeatIntervalTimes=[]; BeatIntervalTimesMean=[]; BeatIntervalTimesSTD=[]; BeatingFrequency=[];
  BeatingFrequency_PerVideoLength=[]; BeatingFrequency_BPM=[];

 if get(handles.MovCentDet,'Value')==1
  
    ROIStr=strcat('_Results@ROI_',num2str(round(ROIProcessed(1)),'%04d'),'_',...
    num2str(round(ROIProcessed(2)),'%04d'),'_',num2str(round(ROIProcessed(3)),'%04d'),'_',num2str(round(ROIProcessed(4)),'%04d'),'_MoC');

    ROIStrIm=strcat('_Results@ROI_',num2str(round(ROIProcessed(1)),'%04d'),'_',...
    num2str(round(ROIProcessed(2)),'%04d'),'_',num2str(round(ROIProcessed(3)),'%04d'),'_',num2str(round(ROIProcessed(4)),'%04d'));
    try
        MoCStr=strcat(PathName,'\',FileNameAVI(1:end-4),ROIStrIm,'_texture_MoC.jpg');
        imwrite(FirstFrameWithROI,MoCStr);
    end

 else
  
    ROIStr=strcat('_Results@ROI_',num2str(round(ROIProcessed(1)),'%04d'),'_',...
    num2str(round(ROIProcessed(2)),'%04d'),'_',num2str(round(ROIProcessed(3)),'%04d'),'_',num2str(round(ROIProcessed(4)),'%04d'));
 end

    if get(handles.MovCentTextureDet,'Value')==1 
        ROIStrIm=strcat('_Results@ROI_',num2str(round(ROIProcessed(1)),'%04d'),'_',...
        num2str(round(ROIProcessed(2)),'%04d'),'_',num2str(round(ROIProcessed(3)),'%04d'),'_',num2str(round(ROIProcessed(4)),'%04d'));
        try
            MoCStr=strcat(PathName,'\',FileNameAVI(1:end-4),ROIStrIm,'_texture_MoC.jpg');
            imwrite(FirstFrameWithROI,MoCStr);
        end
    end
    
    
% % global AVIfilesList
% %FileNr=1:length(AVIfilesList);
% 
%     FileNr=get(handles.SelectFilesListBox,'Value');
%     %FileNameMoCTex=strcat(AVIfilesList(FileNr).name,ROIStr
%  %        ROIStr
% FileNameAVI
% saveStrAVI2MAT

%     if get(handles.MovCentDet,'Value')==1
%         imwrite(FirstFrameWithROI,strcat(saveStrAVI2MAT(1:end-4),'_MoC.jpg'));
%     end
 
 
 
 
 
saveStrAVI2MAT=strcat(PathName,'\',FileNameAVI(1:end-4),ROIStr,'.mat');
% strcat(PathName,'\',FileNameAVI(1:end-4),ROIStr,'_texture_&_MoC.jpg')
% figure, imshow(FirstFrameWithROI)


ROIProcessed=round(ROIProcessed);
   try 
    save(saveStrAVI2MAT,'ROIProcessed','ROITextureCenter','ROIMoveCenter','FirstFrameWithROI','FileNameAVI','FrameRate','FramesTotalNumberInVideo','FrameRate','Vx','Vy','d','r','s1','s2','time','InvertsignalCh','FilterVal',...
      'FrameNrProcessedStart', 'FrameNrProcessedEnd','BaseLinDriftCorCh','FilterVal','InvertsignalCh','FWHMorElse',...
          'State_Level_Tolerances','RelaxationTimes','RelaxationStartTimes','RelaxationEndTimes','RelaxationTimesMean','RelaxationTimesSTD',...
             'RelaxationPeaksIndices','RelaxationPeaksAmplitudes','RelaxationPeaksAmplitudesSTD','RelaxationPeaksAmplitudesMean','ContractionTimes',...
                'ContractionStartTimes','ContractionEndTimes','ContractionTimesMean','ContractionTimesSTD','ContractionPeaksIndices',...
                    'ContractionPeaksAmplitudes','ContractionPeaksAmplitudesSTD','ContractionPeaksAmplitudesMean','BeatIntervalTimes','BeatIntervalTimesMean',...
                        'BeatIntervalTimesSTD','BeatingFrequency_PerVideoLength','BeatingFrequency_BPM');    
    catch
     save(saveStrAVI2MAT,'ROIProcessed','ROITextureCenter','ROIMoveCenter','FileNameAVI','FrameRate','FramesTotalNumberInVideo','FrameRate','Vx','Vy','d','r','s1','s2','time','InvertsignalCh','FilterVal',...
      'FrameNrProcessedStart', 'FrameNrProcessedEnd','BaseLinDriftCorCh','FilterVal','InvertsignalCh','FWHMorElse',...
          'State_Level_Tolerances','RelaxationTimes','RelaxationStartTimes','RelaxationEndTimes','RelaxationTimesMean','RelaxationTimesSTD',...
             'RelaxationPeaksIndices','RelaxationPeaksAmplitudes','RelaxationPeaksAmplitudesSTD','RelaxationPeaksAmplitudesMean','ContractionTimes',...
                'ContractionStartTimes','ContractionEndTimes','ContractionTimesMean','ContractionTimesSTD','ContractionPeaksIndices',...
                    'ContractionPeaksAmplitudes','ContractionPeaksAmplitudesSTD','ContractionPeaksAmplitudesMean','BeatIntervalTimes','BeatIntervalTimesMean',...
                        'BeatIntervalTimesSTD','BeatingFrequency_PerVideoLength','BeatingFrequency_BPM','-append');    
   end



%msgStr='process completed|beating signal extracted';
%set(handles.messageText,'string',msgStr,'Fontsize',13,'FontWeight','bold','ForegroundColor','b');

try
TableData = [[RelaxationTimesMean RelaxationPeaksAmplitudesMean ContractionTimesMean  ContractionPeaksAmplitudesMean BeatIntervalTimesMean BeatingFrequency_BPM]',...
    [RelaxationTimesSTD RelaxationPeaksAmplitudesSTD ContractionTimesSTD ContractionPeaksAmplitudesSTD BeatIntervalTimesSTD nan]'];
set(handles.ParamTable,'data',TableData);
end
%FileNameAVI=saveStrAVI2MAT



% --- Executes on button press in ProcessAll_files.
function ProcessAll_files_Callback(hObject, eventdata, handles)

global xyloObj PathName FileNameAVI ImrectCreateROIst ProcessOrNotState Vx Vy d r s1 s2 time InvertsignalCh BaseLinDriftCorCh FilterVal FrameNrProcessedStart FrameNrProcessedEnd
global ProcessedData ComponentForProcess SelectdDataIndicator ImrectCreateROIst ProcessOrNotState
global AVIfilesList MATfilesList PathName FileNameAVI FileNameMAT xyloObj ImrectCreateROIst ROIProcessed FirstFrameWithROI
global AutoComp AutoFcheckSt

addpath(strcat(pwd,'\fns'));
%ROIst=getPosition(ImrectCreateROIst);
TimSt=datevec(now);
for FileNr=1:length(AVIfilesList)
    FileNameAVI=AVIfilesList(FileNr).name;
        set(handles.SelectFilesListBox,'Value',FileNr);

    xyloObj=VideoReader(strcat(PathName,'/',FileNameAVI));
    axes(handles.axes1); axis off; 
    RefFrameNr=1;
    FrameRate=xyloObj.FrameRate;
    
        if ProcessOrNotState == 0
            break
        end   

        xyloObj.CurrentTime=(RefFrameNr-1)/FrameRate;
        %im1 = im2double(rgb2gray(readFrame(xyloObj)));       
            try
                im1 = im2double(rgb2gray(readFrame(xyloObj)));
            catch
                im1 = im2double(readFrame(xyloObj));
            end
                axes(handles.axes1);imshow(im1); 

        test= (get(handles.userROIbox,'String'));
        num = textscan(test, '%f', 'Delimiter',',' );
        ROIProcessed = permute(num{1},[2,1]);
            [ROIProcessed]= minROIadjuster (ROIProcessed, xyloObj.Width, xyloObj.Height);
   
        try
           delete(ImrectCreateROIst);
           ImrectCreateROIst = drawrectangle(handles.axes1,'Position',ROIProcessed,'Color','g', 'FaceAlpha',0);
           ROIStr=mat2str(round(ROIProcessed));
           set(handles.userROIbox,'string',ROIStr(2:end-1));
         end            
        ROICurrent=addlistener(ImrectCreateROIst,'MovingROI',@allevents);



try
    %ROIProcessed=getPosition(ImrectCreateROIst);  
    TotalFrames = FrameRate*xyloObj.Duration;
    TotalFrames=round(TotalFrames);
        VidLengthStaPercent = str2double(get(handles.VidLengthStaPercent,'String'));
            FrameNrProcessedStart=round(TotalFrames*VidLengthStaPercent/100);
                        if FrameNrProcessedStart==0
                            FrameNrProcessedStart=1;
                        end                      
        VidLengthEndPercent = str2double(get(handles.VidLengthEndPercent,'String'));
            FrameNrProcessedEnd=round(TotalFrames*VidLengthEndPercent/100);
   clear flow;    
       Vx=zeros(TotalFrames,1);
       Vy=zeros(TotalFrames,1);
        d=zeros(TotalFrames,1);
        r=zeros(TotalFrames,1);
       s1=zeros(TotalFrames,1);
       s2=zeros(TotalFrames,1);
  
    vidWidth = round(ROIProcessed(3))+1;
    vidHeight = round(ROIProcessed(4))+1;
    mov = struct('cdata',zeros(vidHeight,vidWidth,3,'uint8'),'colormap',[]);        
    set(handles.ProcessOneFile,'enable','off','BackgroundColor',[0.83  0.82 0.78]);
    set(handles.ProcessAll_files,'enable','off','string','Processing..','BackgroundColor',[0.83  0.82 0.78]); 
    set(handles.ProcessStop,'enable','on','string','Stop Process','BackgroundColor',[0.83  0.82 0.78]);          
    
    PerVec=linspace(1,100,length(FrameNrProcessedStart:FrameNrProcessedEnd-1));
    tic
   for i=FrameNrProcessedStart:FrameNrProcessedEnd-1       
        if ProcessOrNotState == 0
            break
        end   
        
         if i==1
           set(gcf,'paperpositionmode','auto');           
           FirstFrameWithROI=frame2im(getframe(handles.axes1));
                xyloObj.CurrentTime=(i-1)/FrameRate;            
                im1 = readFrame(xyloObj,'native');
            try
                im1=im2double(imcrop(im1(:,:,1),ROIProcessed));          
            catch
                im1=im1.cdata;
                im1=im2double(imcrop(im1(:,:,1),ROIProcessed));  
            end 
         end
                xyloObj.CurrentTime=((i+1)-1)/FrameRate;
                im2 = readFrame(xyloObj,'native');            
            try
                im2=im2double(imcrop(im2(:,:,1),ROIProcessed));          
            catch
                im2=im2.cdata;
                im2=im2double(imcrop(im2(:,:,1),ROIProcessed));  
            end                  
               af = affine_flow('image1', im1, 'image2', im2,'sigmaXY', 12, 'sampleStep',12);     
               im1=im2;
           af = af.findFlow;
           flow = af.flowStruct;   
           Vx(i,:)=flow.vx0;
           Vy(i,:)=flow.vy0;
            d(i,:)=flow.d;
            r(i,:)=flow.r;
           s1(i,:)=flow.s1;
           s2(i,:)=flow.s2;
           
            PercentProcessed = PerVec(i-min(FrameNrProcessedStart:FrameNrProcessedEnd)+1);
            set(handles.messageText,'string',strcat(sprintf('%1.2f',PercentProcessed) ,' %'),'Fontsize',30,'FontWeight','bold','ForegroundColor','b');
   end 
   toc
        Vx=Vx-mean(Vx);% seeting signal mean position to zero
        Vy=Vy-mean(Vy);
         d=d-mean(d);
        r=r-mean(r);
        s1=s1-mean(s1);
        s2=s2-mean(s2);
        
        time=linspace(0,xyloObj.Duration, TotalFrames);       
   
        Vx=medfilt1(Vx,4);% to avoid initial or end large transiets if any
        Vy=medfilt1(Vy,4);
         d=medfilt1(d,4);
        r=medfilt1(r,4);
        s1=medfilt1(s1,4);
        s2=medfilt1(s2,4);
        time=linspace(0,xyloObj.Duration, TotalFrames); 

 AutoFcheckSt=get(handles.AutoFcheck,'Value');
   if AutoFcheckSt ==1
    [SNRi,Fl6Str,AutoComp]=AutoCompSelect(Vx,Vy,d,r,s1,s2);
    cla(handles.axes2,'reset');  
    axes(handles.axes2); 
    text(mean(get(gca,'XLim')),mean(get(gca,'YLim')),'Updating plots','Color','red','FontSize',20);
    plot(time,AutoComp);handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom';axis on; grid on            
   
   for ii=1:6       
       set(eval(['handles.',Fl6Str{SNRi(ii)}]),'Value',0);
       if ii==6
        set(eval(['handles.',Fl6Str{SNRi(6)}]),'Value',1);
       end
   end 
   
   else
            if get(handles.VxCheck,'Value')==1
                SelectdData=Vx; 
                SelectdDataIndicator='Vx';
            elseif get(handles.VyCheck,'Value')==1
                SelectdData=Vy; 
                SelectdDataIndicator='Vy';
            elseif get(handles.DilationCheck,'Value')==1
                SelectdData=d; 
                SelectdDataIndicator='d';
            elseif get(handles.RotationCheck,'Value')==1
                SelectdData=r; 
                SelectdDataIndicator='r';
            elseif get(handles.ShearXCheck,'Value')==1
                SelectdData=s1; 
                SelectdDataIndicator='s1';
            elseif get(handles.ShearDiagCheck,'Value')==1
                SelectdData=s2; 
                SelectdDataIndicator='s2';
            end   
    ComponentForProcess=SelectdDataIndicator;
    cla(handles.axes2,'reset');  
    axes(handles.axes2); 
    text(mean(get(gca,'XLim')),mean(get(gca,'YLim')),'Updating plots','Color','red','FontSize',20);
    plot(time,SelectdData);handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom';axis on; grid on
       
  end


  if  ProcessOrNotState==0
           %set(handles.messageText,'string','Processing aborted','Fontsize',13,'FontWeight','bold','ForegroundColor','k');
  else
      %set(handles.messageText,'string','Processing completed | ready for analysis','Fontsize',13,'FontWeight','bold','ForegroundColor','b');
  end

    set(handles.ProcessOneFile,'enable','on','string','Process select video','BackgroundColor',[0.83  0.82 0.78]);
    set(handles.ProcessStop,'enable','off','string','Stop Process','BackgroundColor',[0.83  0.82 0.78]);
    set(handles.ProcessAll_files,'enable','on','string','Process all videos','BackgroundColor',[0.83  0.82 0.78]); 
 
  catch
    %set(handles.messageText,'string','No data available. Process AVI file(s) first/choose MAT files for postprocessing','Fontsize',13,'FontWeight','bold','ForegroundColor','b');
  end

InvertsignalCh=0; BaseLinDriftCorCh=0; FilterVal=1; set(handles.FilterSlider,'value',FilterVal);
ProcessedData=0; % indicator for measurement data selection
ComponentForProcess='s1';
%SelectdDataIndicator='s1';
%msgStr='process completed|beating signal extracted';
%set(handles.messageText,'string',msgStr,'Fontsize',13,'FontWeight','bold','ForegroundColor','b');

FramesTotalNumberInVideo = TotalFrames;

   %saveStrAVI2MAT=strcat(FileNameAVI(1:end-4),'_AnalysisResults.mat ');
   %saveStrAVI2MAT=strcat(PathName,'\',FileNameAVI(1:end-4),'_AnalysisResults.mat');
   ROIStr=strcat('_Results@ROI_',num2str(round(ROIProcessed(1)),'%04d'),'_',...
    num2str(round(ROIProcessed(2)),'%04d'),'_',num2str(round(ROIProcessed(3)),'%04d'),'_',num2str(round(ROIProcessed(4)),'%04d'));
   saveStrAVI2MAT=strcat(PathName,'\',FileNameAVI(1:end-4),ROIStr,'.mat');      
  % msgStr='saveStrAVI2MAT';
  FWHMorElse=[]; State_Level_Tolerances=[]; RelaxationTimes=[];RelaxationStartTimes=[];RelaxationEndTimes=[]; RelaxationTimesMean=[]; RelaxationTimesSTD=[];
  RelaxationPeaksIndices=[]; RelaxationPeaksAmplitudes=[];RelaxationPeaksAmplitudesSTD=[]; RelaxationPeaksAmplitudesMean=[]; ContractionTimes=[]; ContractionStartTimes=[];
  ContractionEndTimes=[]; ContractionTimesMean=[]; ContractionTimesSTD=[]; ContractionPeaksIndices=[]; ContractionPeaksAmplitudes=[]; ContractionPeaksAmplitudesSTD=[];
  ContractionPeaksAmplitudesMean=[];BeatIntervalTimes=[]; BeatIntervalTimesMean=[]; BeatIntervalTimesSTD=[]; BeatingFrequency=[];
  BeatingFrequency_PerVideoLength=[]; BeatingFrequency_BPM=[];
      save(saveStrAVI2MAT,'ROIProcessed','FirstFrameWithROI','FileNameAVI','FrameRate','FramesTotalNumberInVideo','FrameRate','Vx','Vy','d','r','s1','s2','time','InvertsignalCh','FilterVal',...
      'FrameNrProcessedStart', 'FrameNrProcessedEnd','BaseLinDriftCorCh','FilterVal','InvertsignalCh','FWHMorElse',...
          'State_Level_Tolerances','RelaxationTimes','RelaxationStartTimes','RelaxationEndTimes','RelaxationTimesMean','RelaxationTimesSTD',...
             'RelaxationPeaksIndices','RelaxationPeaksAmplitudes','RelaxationPeaksAmplitudesSTD','RelaxationPeaksAmplitudesMean','ContractionTimes',...
                'ContractionStartTimes','ContractionEndTimes','ContractionTimesMean','ContractionTimesSTD','ContractionPeaksIndices',...
                    'ContractionPeaksAmplitudes','ContractionPeaksAmplitudesSTD','ContractionPeaksAmplitudesMean','BeatIntervalTimes','BeatIntervalTimesMean',...
                        'BeatIntervalTimesSTD','BeatingFrequency_PerVideoLength','BeatingFrequency_BPM');     

                    
                    
  try
        TableData = [[RelaxationTimesMean RelaxationPeaksAmplitudesMean ContractionTimesMean  ContractionPeaksAmplitudesMean BeatIntervalTimesMean BeatingFrequency_BPM]',...
        [RelaxationTimesSTD RelaxationPeaksAmplitudesSTD ContractionTimesSTD ContractionPeaksAmplitudesSTD BeatIntervalTimesSTD nan]'];
        set(handles.ParamTable,'data',TableData);
  end

end
Total_Time_Seconds=etime(datevec(now),TimSt)
      ProcessOrNotState = 1;   



% --- Executes on button press in VxCheck.
function VxCheck_Callback(hObject, eventdata, handles)

global Vx Vy d r s1 s2 time InvertsignalCh BaseLinDriftCorCh FilterVal ComponentForProcess SelectdDataIndicator

 cla(handles.axes2,'reset');  axes(handles.axes2);

 try
     FilterVal=ceil(get(handles.FilterSlider,'Value')); if FilterVal ==0, FilterVal=1; end;    
         SelectdData=Vx; 
         SelectdDataIndicator='Vx';
         ComponentForProcess='Vx';          

    [ProcessedData]=PostProcess(BaseLinDriftCorCh,InvertsignalCh,FilterVal,SelectdData);  
        MAFilterTried=1001; % may or may not be used but tried 

    cla(handles.axes2,'reset');  axes(handles.axes2);
    plot(time,ProcessedData),handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom'; grid on, hold on, %,ylim([mean(ProcessedData)-stdFact*std(ProcessedData) mean(ProcessedData)+stdFact*std(ProcessedData)]),grid on, hold on         
   
catch
    str='Nothing to plot';
end  
 %InvertsignalCh=0; BaseLinDriftCorCh=0; 
 %set(handles.FilterSlider,'value',FilterVal);

%set(handles.messageText,'string','Vx selected','Fontsize',13,'FontWeight','bold','ForegroundColor','b');
set(handles.FilterSlider,'value',FilterVal); %set(handles.BaseLinDriftCorCh,'value',0); set(handles.InvertsignalCh,'value',0);
  set(handles.FilterText,'string',num2str(FilterVal),'Fontsize',9,'FontWeight','bold','ForegroundColor','b');
set(handles.ignoreValleys,'Value',0);set(handles.ignorePeaks,'Value',0);

set(handles.VyCheck,'Value',0);set(handles.DilationCheck,'Value',0); 
set(handles.ShearXCheck,'Value',0);set(handles.ShearDiagCheck,'Value',0);   set(handles.RotationCheck,'Value',0);





% --- Executes on button press in VyCheck.
function VyCheck_Callback(hObject, eventdata, handles)

global Vx Vy d r s1 s2 time InvertsignalCh BaseLinDriftCorCh FilterVal ComponentForProcess SelectdDataIndicator


cla(handles.axes2,'reset');  axes(handles.axes2);

 try
     FilterVal=ceil(get(handles.FilterSlider,'Value')); if FilterVal ==0, FilterVal=1; end;    
         SelectdData=Vy; 
         SelectdDataIndicator='Vy';
         ComponentForProcess='Vy';          

    [ProcessedData]=PostProcess(BaseLinDriftCorCh,InvertsignalCh,FilterVal,SelectdData);  
        MAFilterTried=1001; % may or may not be used but tried 

    cla(handles.axes2,'reset');  axes(handles.axes2);
    plot(time,ProcessedData),handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom'; grid on, hold on, %,ylim([mean(ProcessedData)-stdFact*std(ProcessedData) mean(ProcessedData)+stdFact*std(ProcessedData)]),grid on, hold on         
   
catch
    str='Nothing to plot';
end  
 %InvertsignalCh=0; BaseLinDriftCorCh=0; 
 %set(handles.FilterSlider,'value',FilterVal);

%set(handles.messageText,'string','Vx selected','Fontsize',13,'FontWeight','bold','ForegroundColor','b');
set(handles.FilterSlider,'value',FilterVal); %set(handles.BaseLinDriftCorCh,'value',0); set(handles.InvertsignalCh,'value',0);
  set(handles.FilterText,'string',num2str(FilterVal),'Fontsize',9,'FontWeight','bold','ForegroundColor','b');
set(handles.ignoreValleys,'Value',0);set(handles.ignorePeaks,'Value',0);

set(handles.VxCheck,'Value',0);  set(handles.DilationCheck,'Value',0); 
set(handles.ShearXCheck,'Value',0);set(handles.ShearDiagCheck,'Value',0);   set(handles.RotationCheck,'Value',0);


% --- Executes on button press in DilationCheck.
function DilationCheck_Callback(hObject, eventdata, handles)

global Vx Vy d r s1 s2 time InvertsignalCh BaseLinDriftCorCh FilterVal ComponentForProcess SelectdDataIndicator

cla(handles.axes2,'reset');  axes(handles.axes2);

 try
     FilterVal=ceil(get(handles.FilterSlider,'Value')); if FilterVal ==0, FilterVal=1; end;    
         SelectdData=d; 
         SelectdDataIndicator='d';
         ComponentForProcess='d';          

    [ProcessedData]=PostProcess(BaseLinDriftCorCh,InvertsignalCh,FilterVal,SelectdData);  
        MAFilterTried=1001; % may or may not be used but tried 

    cla(handles.axes2,'reset');  axes(handles.axes2);
    plot(time,ProcessedData),handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom'; grid on, hold on, %,ylim([mean(ProcessedData)-stdFact*std(ProcessedData) mean(ProcessedData)+stdFact*std(ProcessedData)]),grid on, hold on         
   
catch
    str='Nothing to plot';
end  
 %InvertsignalCh=0; BaseLinDriftCorCh=0; 
 %set(handles.FilterSlider,'value',FilterVal);

%set(handles.messageText,'string','Vx selected','Fontsize',13,'FontWeight','bold','ForegroundColor','b');
set(handles.FilterSlider,'value',FilterVal); %set(handles.BaseLinDriftCorCh,'value',0); set(handles.InvertsignalCh,'value',0);
  set(handles.FilterText,'string',num2str(FilterVal),'Fontsize',9,'FontWeight','bold','ForegroundColor','b');
set(handles.ignoreValleys,'Value',0);set(handles.ignorePeaks,'Value',0);

set(handles.VxCheck,'Value',0);  set(handles.VyCheck,'Value',0);
set(handles.ShearXCheck,'Value',0);set(handles.ShearDiagCheck,'Value',0);   set(handles.RotationCheck,'Value',0);


% --- Executes on button press in RotationCheck.
function RotationCheck_Callback(hObject, eventdata, handles)

global Vx Vy d r s1 s2 time InvertsignalCh BaseLinDriftCorCh FilterVal ComponentForProcess SelectdDataIndicator

cla(handles.axes2,'reset');  axes(handles.axes2);

 try
     FilterVal=ceil(get(handles.FilterSlider,'Value')); if FilterVal ==0, FilterVal=1; end;    
         SelectdData=r; 
         SelectdDataIndicator='r';
         ComponentForProcess='r';          

    [ProcessedData]=PostProcess(BaseLinDriftCorCh,InvertsignalCh,FilterVal,SelectdData);  
        MAFilterTried=1001; % may or may not be used but tried 

    cla(handles.axes2,'reset');  axes(handles.axes2);
    plot(time,ProcessedData),handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom'; grid on, hold on, %,ylim([mean(ProcessedData)-stdFact*std(ProcessedData) mean(ProcessedData)+stdFact*std(ProcessedData)]),grid on, hold on         
   
catch
    str='Nothing to plot';
end  
 %InvertsignalCh=0; BaseLinDriftCorCh=0; 
 %set(handles.FilterSlider,'value',FilterVal);

%set(handles.messageText,'string','Vx selected','Fontsize',13,'FontWeight','bold','ForegroundColor','b');
set(handles.FilterSlider,'value',FilterVal); %set(handles.BaseLinDriftCorCh,'value',0); set(handles.InvertsignalCh,'value',0);
  set(handles.FilterText,'string',num2str(FilterVal),'Fontsize',9,'FontWeight','bold','ForegroundColor','b');
set(handles.ignoreValleys,'Value',0);set(handles.ignorePeaks,'Value',0);

set(handles.VxCheck,'Value',0);  set(handles.VyCheck,'Value',0);set(handles.DilationCheck,'Value',0); 
set(handles.ShearXCheck,'Value',0);set(handles.ShearDiagCheck,'Value',0);   


% --- Executes on button press in ShearXCheck.
function ShearXCheck_Callback(hObject, eventdata, handles)

global Vx Vy d r s1 s2 time InvertsignalCh BaseLinDriftCorCh FilterVal ComponentForProcess SelectdDataIndicator


cla(handles.axes2,'reset');  axes(handles.axes2);

 try
     FilterVal=ceil(get(handles.FilterSlider,'Value')); if FilterVal ==0, FilterVal=1; end;    
         SelectdData=s1; 
         SelectdDataIndicator='s1';
         ComponentForProcess='s1';          

    [ProcessedData]=PostProcess(BaseLinDriftCorCh,InvertsignalCh,FilterVal,SelectdData);  
        MAFilterTried=1001; % may or may not be used but tried 

    cla(handles.axes2,'reset');  axes(handles.axes2);
    plot(time,ProcessedData),handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom'; grid on, hold on, %,ylim([mean(ProcessedData)-stdFact*std(ProcessedData) mean(ProcessedData)+stdFact*std(ProcessedData)]),grid on, hold on         
   
catch
    str='Nothing to plot';
end  
 %InvertsignalCh=0; BaseLinDriftCorCh=0; 
 %set(handles.FilterSlider,'value',FilterVal);

%set(handles.messageText,'string','Vx selected','Fontsize',13,'FontWeight','bold','ForegroundColor','b');
set(handles.FilterSlider,'value',FilterVal); %set(handles.BaseLinDriftCorCh,'value',0); set(handles.InvertsignalCh,'value',0);
  set(handles.FilterText,'string',num2str(FilterVal),'Fontsize',9,'FontWeight','bold','ForegroundColor','b');
set(handles.ignoreValleys,'Value',0);set(handles.ignorePeaks,'Value',0);



set(handles.VxCheck,'Value',0);  set(handles.VyCheck,'Value',0);set(handles.DilationCheck,'Value',0); 
set(handles.ShearDiagCheck,'Value',0);   set(handles.RotationCheck,'Value',0);

 
 


% --- Executes on button press in ShearDiagCheck.
function ShearDiagCheck_Callback(hObject, eventdata, handles)

global Vx Vy d r s1 s2 time InvertsignalCh BaseLinDriftCorCh FilterVal ComponentForProcess SelectdDataIndicator


cla(handles.axes2,'reset');  axes(handles.axes2);

 try
     FilterVal=ceil(get(handles.FilterSlider,'Value')); if FilterVal ==0, FilterVal=1; end;    
         SelectdData=s2; 
         SelectdDataIndicator='s2';
         ComponentForProcess='s2';          
    [ProcessedData]=PostProcess(BaseLinDriftCorCh,InvertsignalCh,FilterVal,SelectdData);  
        MAFilterTried=1001; % may or may not be used but tried 

    cla(handles.axes2,'reset');  axes(handles.axes2);
    plot(time,ProcessedData),handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom'; grid on, hold on, %,ylim([mean(ProcessedData)-stdFact*std(ProcessedData) mean(ProcessedData)+stdFact*std(ProcessedData)]),grid on, hold on         
   
catch
    str='Nothing to plot';
end  
 %InvertsignalCh=0; BaseLinDriftCorCh=0; 
 %set(handles.FilterSlider,'value',FilterVal);

%set(handles.messageText,'string','Vx selected','Fontsize',13,'FontWeight','bold','ForegroundColor','b');
set(handles.FilterSlider,'value',FilterVal); %set(handles.BaseLinDriftCorCh,'value',0); set(handles.InvertsignalCh,'value',0);
  set(handles.FilterText,'string',num2str(FilterVal),'Fontsize',9,'FontWeight','bold','ForegroundColor','b');
set(handles.ignoreValleys,'Value',0);set(handles.ignorePeaks,'Value',0);




set(handles.VxCheck,'Value',0);  set(handles.VyCheck,'Value',0);set(handles.DilationCheck,'Value',0); 
set(handles.ShearXCheck,'Value',0); set(handles.RotationCheck,'Value',0);



% --- Executes on button press in BaseLinDriftCorCh.
function BaseLinDriftCorCh_Callback(hObject, eventdata, handles)
% hObject    handle to BaseLinDriftCorCh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Vx Vy d r s1 s2 time InvertsignalCh BaseLinDriftCorCh FilterVal ProcessedData SelectdDataIndicator BaseLinDriftCorrTried
addpath(strcat(pwd,'\fns'));
BaseLinDriftCorCh=get(handles.BaseLinDriftCorCh,'Value');


try
    
    if get(handles.VxCheck,'Value')==1
        SelectdData=Vx; 
        SelectdDataIndicator='Vx';
    elseif get(handles.VyCheck,'Value')==1
        SelectdData=Vy; 
        SelectdDataIndicator='Vy';
    elseif get(handles.DilationCheck,'Value')==1
        SelectdData=d; 
        SelectdDataIndicator='d';
    elseif get(handles.RotationCheck,'Value')==1
        SelectdData=r; 
        SelectdDataIndicator='r';
    elseif get(handles.ShearXCheck,'Value')==1
        SelectdData=s1; 
        SelectdDataIndicator='s1';
    elseif get(handles.ShearDiagCheck,'Value')==1
        SelectdData=s2; 
        SelectdDataIndicator='s2';
    end   
   
   
    [ProcessedData]=PostProcess(BaseLinDriftCorCh,InvertsignalCh,FilterVal,SelectdData);  
    
    BaseLinDriftCorrTried=1001; % may or may not be used but tried 
    cla(handles.axes2,'reset');  axes(handles.axes2);
    plot(time,ProcessedData),grid on, hold on, %,ylim([mean(ProcessedData)-stdFact*std(ProcessedData) mean(ProcessedData)+stdFact*std(ProcessedData)]),grid on, hold on         
    handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom';
catch
    str='Nothing to plot';
end   
FilterVal=ceil(get(handles.FilterSlider,'Value')); if FilterVal ==0, FilterVal=1; end;
  set(handles.FilterText,'string',num2str(FilterVal),'Fontsize',9,'FontWeight','bold','ForegroundColor','b');
%set(handles.messageText,'string','Base line drift corrected','Fontsize',13,'FontWeight','bold','ForegroundColor','b');
%BaseLinDriftCorCh

% --- Executes on slider movement.
function FilterSlider_Callback(hObject, eventdata, handles)

global Vx Vy d r s1 s2 time InvertsignalCh BaseLinDriftCorCh FilterVal ProcessedData SelectdDataIndicator MAFilterTried
addpath(strcat(pwd,'\fns'));

FilterVal=ceil(get(handles.FilterSlider,'Value')); if FilterVal ==0, FilterVal=1; end
%FilterVal
try
    
    if get(handles.VxCheck,'Value')==1
        SelectdData=Vx; 
        SelectdDataIndicator='Vx';
    elseif get(handles.VyCheck,'Value')==1
        SelectdData=Vy; 
        SelectdDataIndicator='Vy';
    elseif get(handles.DilationCheck,'Value')==1
        SelectdData=d; 
        SelectdDataIndicator='d';
    elseif get(handles.RotationCheck,'Value')==1
        SelectdData=r; 
        SelectdDataIndicator='r';
    elseif get(handles.ShearXCheck,'Value')==1
        SelectdData=s1; 
        SelectdDataIndicator='s1';
    elseif get(handles.ShearDiagCheck,'Value')==1
        SelectdData=s2; 
        SelectdDataIndicator='s2';
    end   
    
   
    [ProcessedData]=PostProcess(BaseLinDriftCorCh,InvertsignalCh,FilterVal,SelectdData);  
        MAFilterTried=1001; % may or may not be used but tried 

    cla(handles.axes2,'reset');  axes(handles.axes2);
    plot(time,ProcessedData),handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom'; grid on, hold on, %,ylim([mean(ProcessedData)-stdFact*std(ProcessedData) mean(ProcessedData)+stdFact*std(ProcessedData)]),grid on, hold on         
   
catch
    str='Nothing to plot';
end   
FilterVal=ceil(get(handles.FilterSlider,'Value')); if FilterVal ==0, FilterVal=1; end;
  set(handles.FilterText,'string',num2str(FilterVal),'Fontsize',9,'FontWeight','bold','ForegroundColor','b');
%set(handles.messageText,'string','MA filter applied','Fontsize',13,'FontWeight','bold','ForegroundColor','b');
%FilterVal


% --- Executes on button press in InvertsignalCh.
function InvertsignalCh_Callback(hObject, eventdata, handles)

global Vx Vy d r s1 s2 time InvertsignalCh BaseLinDriftCorCh FilterVal ProcessedData SelectdDataIndicator InvertsignalTried
addpath(strcat(pwd,'\fns'));

InvertsignalCh=get(handles.InvertsignalCh,'Value');

try
    
    if get(handles.VxCheck,'Value')==1
        SelectdData=Vx; 
        SelectdDataIndicator='Vx';
    elseif get(handles.VyCheck,'Value')==1
        SelectdData=Vy; 
        SelectdDataIndicator='Vy';
    elseif get(handles.DilationCheck,'Value')==1
        SelectdData=d; 
        SelectdDataIndicator='d';
    elseif get(handles.RotationCheck,'Value')==1
        SelectdData=r; 
        SelectdDataIndicator='r';
    elseif get(handles.ShearXCheck,'Value')==1
        SelectdData=s1; 
        SelectdDataIndicator='s1';
    elseif get(handles.ShearDiagCheck,'Value')==1
        SelectdData=s2; 
        SelectdDataIndicator='s2';
    end     
   
     [ProcessedData]=PostProcess(BaseLinDriftCorCh,InvertsignalCh,FilterVal,SelectdData);  
       InvertsignalTried=1001; % may or may not be used but tried 

%         ProcessedData=max(SelectdData)-SelectdData; % inverting the signal  
%         ProcessedData=ProcessedData-mean(ProcessedData); % seeting signal mean position to zero   
       
       
    cla(handles.axes2,'reset');  axes(handles.axes2);
    plot(time,ProcessedData),grid on, hold on, %,ylim([mean(ProcessedData)-stdFact*std(ProcessedData) mean(ProcessedData)+stdFact*std(ProcessedData)]),grid on, hold on         
    handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom';
catch
    str='Nothing to plot';
end   
FilterVal=ceil(get(handles.FilterSlider,'Value')); if FilterVal ==0, FilterVal=1; end;
  set(handles.FilterText,'string',num2str(FilterVal),'Fontsize',9,'FontWeight','bold','ForegroundColor','b');  
  %set(handles.messageText,'string','Signal inverted','Fontsize',13,'FontWeight','bold','ForegroundColor','b');
%InvertsignalCh
 

% --- Executes on button press in MeasureBeatParameters.
function MeasureBeatParameters_Callback(hObject, eventdata, handles)
% hObject    handle to MeasureBeatParameters (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Vx Vy d r s1 s2 time  xyloObj FrameNrProcessedStart FrameNrProcessedEnd ComponentForProcess
global ROIProcessed xyloObj PathName FileNameAVI FileNameMAT FrameRate InvertsignalCh   FilterVal FrameNrProcessedStart FrameNrProcessedEnd...  
ComponentForProcess BaseLinDriftCorCh FilterVal InvertsignalCh FWHMorElse State_Level_Tolerances  RelaxationTimes RelaxationStartTimes RelaxationEndTimes...
RelaxationTimesMean RelaxationTimesSTD RelaxationPeaksIndices RelaxationPeaksAmplitudes RelaxationPeaksAmplitudesSTD RelaxationPeaksAmplitudesMean...
ContractionTimes ContractionStartTimes ContractionEndTimes ContractionTimesMean ContractionTimesSTD ContractionPeaksIndices ContractionPeaksAmplitudes...
ContractionPeaksAmplitudesSTD ContractionPeaksAmplitudesMean BeatIntervalTimes BeatIntervalTimesMean BeatIntervalTimesSTD durationProcessed SelectdDataIndicator...
InvertsignalTried MAFilterTried BaseLinDriftCorrTried FirstFrameWithROI ignorePeaks ignoreValleys BaseLinDriftCorCh InvertsignalCh FilterVal FramesTotalNumberInVideo
global Final_plot ComponentForProcess FramesTotalNumberInVideo Line1 Line2 %FilterVal 
global AutoFcheckSt BeatingFrequency BeatingFrequency_PerVideoLength BeatingFrequency_BPM
% clc, 101
% BeatingFrequency_PerVideoLength 
% BeatingFrequency_BPM
    AutoFcheckSt=get(handles.AutoFcheck,'Value');

%ComponentForProcess
try
             Line1pos2=getPosition(Line1);
             Line2pos2=getPosition(Line2);
end

addpath(strcat(pwd,'\fns'));
set(handles.MeasureBeatParameters,'enable','off');
%pos2=getPosition(hat)

WhichComponent=[get(handles.VxCheck,'Value') get(handles.VyCheck,'Value') get(handles.DilationCheck,'Value') get(handles.RotationCheck,'Value') get(handles.ShearXCheck,'Value') get(handles.ShearDiagCheck,'Value')];

[IndRaw IndCol] = find(WhichComponent==nonzeros(WhichComponent));
components={'Vx' 'Vy' 'd' 'r' 's1' 's2'};
        ComponentForProcess=components{max(IndCol)};
    ProcessedData2=eval(components{max(IndCol)});
    
    
   try
       if AutoFcheckSt ==1
   
    [SNRi,Fl6Str,AutoComp]=AutoCompSelect(Vx,Vy,d,r,s1,s2);
    cla(handles.axes2,'reset');  
    axes(handles.axes2); plot(time,AutoComp);handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom';axis on; grid on            
    [ProcessedData2]=PostProcess(BaseLinDriftCorCh,InvertsignalCh,FilterVal,AutoComp);

   for ii=1:6       
       set(eval(['handles.',Fl6Str{SNRi(ii)}]),'Value',0);
       if ii==6
        set(eval(['handles.',Fl6Str{SNRi(6)}]),'Value',1);
       end
   end 
   
       else
           
           
               
           
%     if get(handles.VxCheck,'Value')==1
%         SelectdData=Vx; 
%         SelectdDataIndicator='Vx';
%     elseif get(handles.VyCheck,'Value')==1
%         SelectdData=Vy; 
%         SelectdDataIndicator='Vy';
%     elseif get(handles.DilationCheck,'Value')==1
%         SelectdData=d; 
%         SelectdDataIndicator='d';
%     elseif get(handles.RotationCheck,'Value')==1
%         SelectdData=r; 
%         SelectdDataIndicator='r';
%     elseif get(handles.ShearXCheck,'Value')==1
%         SelectdData=s1; 
%         SelectdDataIndicator='s1';
%     elseif get(handles.ShearDiagCheck,'Value')==1
%         SelectdData=s2; 
%         SelectdDataIndicator='s2';
%     end     
%            
%           
%            ComponentForProcess=SelectdData;
           
           
    [ProcessedData2]=PostProcess(BaseLinDriftCorCh,InvertsignalCh,FilterVal,eval(ComponentForProcess));
   end
   end
   
 
    
    
try
TableData = [[]',[]'];
set(handles.ParamTable,'data',TableData);
%pause(3)
end


cla(handles.axes2,'reset');  axes(handles.axes2); handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom';
hp1=plot(time,ProcessedData2); hold on,grid on   %, ylim([mean(ProcessedData2)-stdFact*std(ProcessedData2) mean(ProcessedData2)+stdFact*std(ProcessedData2)]),grid on,         


FWHMorElse=str2double(get(handles.FWHM_or_what,'String'));
State_Level_Tolerances=str2double(get(handles.TolFacor,'String'));

    if FWHMorElse >98
        FWHMorElse=98; % setting maximum possible width percentage     
    end
    %FWHMorElse=100-FWHMorElse;
    if FWHMorElse < 65 % FWHMorElse+State_Level_Tolerances should not be more than 100 for the function
        State_Level_Tolerances=35;
    else
        State_Level_Tolerances=99-FWHMorElse;
    end

    if State_Level_Tolerances > FWHMorElse
        State_Level_Tolerances=0.9*FWHMorElse;
    end
%State_Level_Tolerances=35;
 ignoreValleys=get(handles.ignoreValleys,'Value');
ignorePeaks=get(handles.ignorePeaks,'Value');
        %State_Level_Tolerances=40;


Xlims=get(handles.axes2,'XLim');Ylims=get(handles.axes2,'YLim');
    Line1pos1=[Xlims(1) Ylims(1);Xlims(1) Ylims(2)];
    Line2pos1=[Xlims(2) Ylims(1);Xlims(2) Ylims(2)];

if exist('Line1pos2')==1, Line1pos1=Line1pos2; end
if exist('Line2pos2')==1, Line2pos1=Line2pos2; end

    Line1 = imline(handles.axes2,Line1pos1);  Line2 = imline(handles.axes2,Line2pos1);
      [~,Line1idx] = min(abs(Line1pos1(1)-time)); [~,Line2idx] = min(abs(Line2pos1(1)-time));

if Line1idx == 1
    Line1idx =round(length(Vx)*0.03);
end

if Line2idx == length(Vx)
    Line2idx =length(Vx)-round(length(Vx)*0.03);
end
        xRange=Line1idx:Line2idx;
 
try
     if ignorePeaks==0 
        xR=ProcessedData2;
        xR(xR<0)=0; % setting contraction part to zero| to process only the relaxtion signal
            statelevelsRelx=statelevels(xR(xRange),50);% initially it was 100. To skip initial transients it is set to 80
            %statelevelsRelx =[ 0.0    0.005]      
            [RelaxationTimes,initcrossR,finalcrossR] = pulsewidth(xR,time,'StateLevels',statelevelsRelx,'MidPercentReferenceLevel',FWHMorElse,'Tolerance',State_Level_Tolerances);               
            %RelaxationTimes
             RelxPeakWidthFactor=(get(handles.PeakWidthMeanSlider1,'Value'))*mean(RelaxationTimes);             
             set(handles.PeakWidthMeanSlider1text,'string',num2str(RelxPeakWidthFactor),'Fontsize',8,'FontWeight','bold','ForegroundColor','k'); 
             
                 [RelxIndSkipRaw,RelxIndSkipCol]=find(RelaxationTimes < RelxPeakWidthFactor);                
             %    RelxIndSkipRaw
             
                 CorrectRelxIndices=setdiff(1:length(RelaxationTimes),RelxIndSkipRaw);             
                     RelaxationTimes=RelaxationTimes(CorrectRelxIndices);
                     initcrossR=initcrossR(CorrectRelxIndices);
                     finalcrossR=finalcrossR(CorrectRelxIndices);                 
                 RelaxationStartTimes=initcrossR; 
                 RelaxationEndTimes=finalcrossR;
                        RelaxationTimesMean=mean(RelaxationTimes);                                
                        RelaxationTimesSTD=std(RelaxationTimes);
            
          axes(handles.axes2); handles.axes2.YAxisLocation = 'left'; handles.axes2.XAxisLocation ='bottom';    
            FWHMorElse2=(statelevelsRelx(2)-statelevelsRelx(1))*FWHMorElse/100;
            hp2=plot(initcrossR,FWHMorElse2*ones(1,length(initcrossR)),'rx');hold on, 
            hp3=plot(finalcrossR,FWHMorElse2*ones(1,length(initcrossR)),'rx');hold on
            hp4=plot(time,FWHMorElse2*ones(1,length(time)),'r-.');hold on

%             %---------to print high quality plot
%             hp1=plot(time,ProcessedData2,'Color',[0 101 183]./255,'LineWidth',2.5); 
%             hp2=plot(initcrossR,FWHMorElse2*ones(1,length(initcrossR)),'rx','LineWidth',2.5,'MarkerSize',12);hold on, 
%             hp3=plot(finalcrossR,FWHMorElse2*ones(1,length(initcrossR)),'rx','LineWidth',2.5,'MarkerSize',12);hold on
%             hp4=plot(time,FWHMorElse2*ones(1,length(time)),'r-.','LineWidth',1.5,'MarkerSize',12);hold on
%            %---------to print high quality plot

                try
                   [~,RelaxationPeaksIndices] = min(abs(((initcrossR+finalcrossR)/2)'-time'));
                   RelaxationPeaksAmplitudes=ProcessedData2(RelaxationPeaksIndices);
                   RelaxationPeaksAmplitudesSTD=std(RelaxationPeaksAmplitudes);
                   RelaxationPeaksAmplitudesMean=mean(RelaxationPeaksAmplitudes);
                       BeatIntervalTimes=time(RelaxationPeaksIndices);
                       BeatIntervalTimesMean=mean(diff(BeatIntervalTimes));
                       BeatIntervalTimesSTD=std(diff(BeatIntervalTimes));
                       BeatingFrequency=length(RelaxationTimes);
                end
     else
                RelaxationStartTimes=nan;
                RelaxationEndTimes=nan;
                RelaxationTimesMean=nan;
                RelaxationTimesSTD=nan;     
                   RelaxationPeaksIndices =nan;
                   RelaxationPeaksAmplitudes=nan;
                   RelaxationPeaksAmplitudesSTD=nan;
                   RelaxationPeaksAmplitudesMean=nan;
                       BeatIntervalTimes=nan;
                       BeatIntervalTimesMean=nan;
                       BeatIntervalTimesSTD=nan;
                       BeatingFrequency=nan;
     end             
    
    
      
    if ignoreValleys==0     
                xC=ProcessedData2;
            xC(xC>0)=0; % setting realxation  part to zero| to process only the contraction signal
            xC=abs(xC);
                statelevelsCont=statelevels(xC(xRange),50);% initially it was 100. To skip initial transients in relx signal it is set to 80
                [ContractionTimes,initcrossC,finalcrossC] = pulsewidth(xC,time,'StateLevels',statelevelsCont,'MidPercentReferenceLevel',FWHMorElse,'Tolerance',State_Level_Tolerances);
                            ContPeakWidthFactor=(get(handles.PeakWidthMeanSlider2,'Value'))*mean(ContractionTimes);             
                            set(handles.PeakWidthMeanSlider2text,'string',num2str(ContPeakWidthFactor),'Fontsize',8,'FontWeight','bold','ForegroundColor','k');
                 [ContIndSkipRaw,ContIndSkipCol]=find(ContractionTimes < ContPeakWidthFactor);                
                 CorrectContIndices=setdiff(1:length(ContractionTimes),ContIndSkipRaw);             
                     ContractionTimes=ContractionTimes(CorrectContIndices);
                     initcrossC=initcrossC(CorrectContIndices);
                     finalcrossC=finalcrossC(CorrectContIndices);                 
                        ContractionStartTimes=initcrossC;
                        ContractionEndTimes=finalcrossC;
                        ContractionTimesMean=mean(ContractionTimes);
                        ContractionTimesSTD=std(ContractionTimes);
              
              axes(handles.axes2);handles.axes2.YAxisLocation = 'left';
                FWHMorElse2=(statelevelsCont(2)-statelevelsCont(1))*FWHMorElse/100;
                hp5=plot(initcrossC,-1*FWHMorElse2*ones(1,length(initcrossC)),'bx'); hold on
                hp6=plot(finalcrossC,-1*FWHMorElse2*ones(1,length(initcrossC)),'bx'); hold on
                hp7=plot(time,-1*FWHMorElse2*ones(1,length(time)),'b-.'); hold on
                
% %---------to print high quality plot               
%                 hp5=plot(initcrossC,-1*FWHMorElse2*ones(1,length(initcrossC)),'bx','MarkerSize',12,'LineWidth',2.5); hold on
%                 hp6=plot(finalcrossC,-1*FWHMorElse2*ones(1,length(initcrossC)),'bx','MarkerSize',12,'LineWidth',2.5); hold on
%                 hp7=plot(time,-1*FWHMorElse2*ones(1,length(time)),'b-.','LineWidth',1.5); hold on
% %---------to print high quality plot
        
        try
            [~,ContractionPeaksIndices] = min(abs(((initcrossC+finalcrossC)/2)'-time'));
            ContractionPeaksAmplitudes=ProcessedData2(ContractionPeaksIndices);
            ContractionPeaksAmplitudesSTD=std(ContractionPeaksAmplitudes);
            ContractionPeaksAmplitudesMean=mean(ContractionPeaksAmplitudes);
            %plot(time(ContractionPeaksIndices),ContraPeakAmplitude,'b-.'),hold on
            %plot(time(RelaxPeakIdx),RelaxPeakAmplitude,'b-.'),hold on
                BeatIntervalTimes=time(ContractionPeaksIndices);
                BeatIntervalTimesMean=mean(diff(BeatIntervalTimes));
                BeatIntervalTimesSTD=std(diff(BeatIntervalTimes));
                BeatingFrequency=length(ContractionTimes);  
                 
        end

    else
            ContractionStartTimes=nan;
            ContractionEndTimes=nan;
            ContractionTimesMean=nan;
            ContractionTimesSTD=nan;
            ContractionPeaksIndices=nan;
            ContractionPeaksAmplitudes=nan;
            ContractionPeaksAmplitudesSTD=nan;
            ContractionPeaksAmplitudesMean=nan;
                       BeatIntervalTimes=time(RelaxationPeaksIndices);  
                       BeatIntervalTimesMean=mean(diff(BeatIntervalTimes));
                       BeatIntervalTimesSTD=std(diff(BeatIntervalTimes));
                       BeatingFrequency=length(RelaxationTimes);
  
    end  

        durationProcessed_Org=length(FrameNrProcessedStart:FrameNrProcessedEnd)/FrameRate;
        durationProcessed=sprintf('%1.1f',durationProcessed_Org);
%                        handles.ParamTable.RowName{6} = strcat('Beating frequency (beats/',num2str(durationProcessed),'s)');    

        BeatingFrequency_PerVideoLength=BeatingFrequency;        
        BeatingFrequency_BPM=BeatingFrequency*60/durationProcessed_Org;
                        handles.ParamTable.RowName{6} = 'Beating frequency (beats per minute)'; 
                     
        FilterVal=FilterVal;
        
        % RelaxationTimesMean
        % ContractionTimesMean

try
    warning('off',id); rmpath('MATLAB:legend:IgnoringExtraEntries'); % in case extra legend warning pops up duo to some issues with data file
end

 if ignorePeaks==1
         legend([hp1 hp5 hp7],{strcat('signal:',ComponentForProcess),'contraction peak width',strcat('contraction:',num2str(FWHMorElse),'%',char(3),'level')});
    elseif ignoreValleys==1       
         legend([hp1 hp2 hp4],{strcat('signal:',ComponentForProcess),'relaxation peak width',strcat('relaxation:',num2str(FWHMorElse),'%',char(3),'level')});
    elseif ignorePeaks==0 && ignoreValleys==0       
         legend([hp1 hp2 hp4 hp5 hp7],{strcat('signal:',ComponentForProcess),'relaxation peak width',strcat('relaxation:',num2str(FWHMorElse),'%',char(3),'level'),'contraction peak width',strcat('contraction:',num2str(FWHMorElse),'%',char(3),'level')});
 end

 xlim([min(time)-10*mean(time(1:5)) max(time)+10*mean(time(1:5))]);
       
try

% TableData = [[RelaxationTimesMean RelaxationPeaksAmplitudesMean ContractionTimesMean  ContractionPeaksAmplitudesMean BeatIntervalTimesMean BeatingFrequency]',...
%     [RelaxationTimesSTD RelaxationPeaksAmplitudesSTD ContractionTimesSTD ContractionPeaksAmplitudesSTD BeatIntervalTimesSTD nan]'];
TableData = [[RelaxationTimesMean RelaxationPeaksAmplitudesMean ContractionTimesMean  ContractionPeaksAmplitudesMean BeatIntervalTimesMean BeatingFrequency_BPM]',...
    [RelaxationTimesSTD RelaxationPeaksAmplitudesSTD ContractionTimesSTD ContractionPeaksAmplitudesSTD BeatIntervalTimesSTD nan]'];
set(handles.ParamTable,'data',TableData);
end

end

%      try
%             hFigure = findall(0,'Name','Software_CMaN');
%             frameData = getframe(hFigure);
%             Final_plot = frameData.cdata;
%      end   
     
       DataX=[time' Vx Vy d r s1 s2];
%          FinalF=getframe(handles.axes2);      Final_plot=FinalF.cdata;   figure, image(Final_plot)
       Final_plot=frame2im(getframe(handles.axes2));
       Final_plot_GUI=frame2im(getframe(gcf));
       
       
       FilterVal=FilterVal;
       SelectdDataIndicator=ComponentForProcess;

if isempty(FramesTotalNumberInVideo) ==1
    FramesTotalNumberInVideo=length(time);
end



if get(handles.SaveWithMeasure,'Value')==1

    if get(handles.selectMatCh,'Value')==1  
        saveStrMAT2MAT=strcat(PathName,'\',FileNameMAT); %msgStr='saveStrMAT2MAT';    
        save(saveStrMAT2MAT,'ROIProcessed','FirstFrameWithROI','Final_plot','FileNameAVI','FileNameMAT','FrameRate','FramesTotalNumberInVideo','FrameRate','Vx','Vy','d','r','s1','s2','time','InvertsignalCh','FilterVal',...
          'FrameNrProcessedStart','FrameNrProcessedEnd','SelectdDataIndicator','BaseLinDriftCorCh','FilterVal','InvertsignalCh','FWHMorElse',...
              'State_Level_Tolerances','RelaxationTimes','RelaxationStartTimes','RelaxationEndTimes','RelaxationTimesMean','RelaxationTimesSTD',...
                 'RelaxationPeaksIndices','RelaxationPeaksAmplitudes','RelaxationPeaksAmplitudesSTD','RelaxationPeaksAmplitudesMean','ContractionTimes',...
                    'ContractionStartTimes','ContractionEndTimes','ContractionTimesMean','ContractionTimesSTD','ContractionPeaksIndices',...
                        'ContractionPeaksAmplitudes','ContractionPeaksAmplitudesSTD','ContractionPeaksAmplitudesMean','BeatIntervalTimes','BeatIntervalTimesMean',...
                            'BeatIntervalTimesSTD','BeatingFrequency_PerVideoLength','BeatingFrequency_BPM','-append');    
    elseif get(handles.selectAVICh,'Value')==1 
       
       saveStrAVI2MAT=strcat(FileNameAVI(1:end-4),'_AnalysisResults.mat ');
        saveStrAVI2MAT=strcat(PathName,'\',FileNameMAT); %msgstr='saveStrMAT2MAT';    

       %msgstr='saveStrAVI2MAT';
       
       try
       
        save(saveStrAVI2MAT,'ROIProcessed','FileNameAVI','Final_plot','FileNameMAT','FrameRate','FramesTotalNumberInVideo','FrameRate','Vx','Vy','d','r','s1','s2','time','InvertsignalCh','FilterVal',...
          'FrameNrProcessedStart', 'FrameNrProcessedEnd','SelectdDataIndicator','BaseLinDriftCorCh','FilterVal','InvertsignalCh','FWHMorElse',...
              'State_Level_Tolerances','RelaxationTimes','RelaxationStartTimes','RelaxationEndTimes','RelaxationTimesMean','RelaxationTimesSTD',...
                 'RelaxationPeaksIndices','RelaxationPeaksAmplitudes','RelaxationPeaksAmplitudesSTD','RelaxationPeaksAmplitudesMean','ContractionTimes',...
                    'ContractionStartTimes','ContractionEndTimes','ContractionTimesMean','ContractionTimesSTD','ContractionPeaksIndices',...
                        'ContractionPeaksAmplitudes','ContractionPeaksAmplitudesSTD','ContractionPeaksAmplitudesMean','BeatIntervalTimes','BeatIntervalTimesMean',...
                            'BeatIntervalTimesSTD','BeatingFrequency_PerVideoLength','BeatingFrequency_BPM','-append');    
        catch
                save(saveStrAVI2MAT,'ROIProcessed','FileNameAVI','FileNameMAT','FrameRate','FramesTotalNumberInVideo','FrameRate','Vx','Vy','d','r','s1','s2','time','InvertsignalCh','FilterVal',...
          'FrameNrProcessedStart', 'FrameNrProcessedEnd','SelectdDataIndicator','BaseLinDriftCorCh','FilterVal','InvertsignalCh','FWHMorElse',...
              'State_Level_Tolerances','RelaxationTimes','RelaxationStartTimes','RelaxationEndTimes','RelaxationTimesMean','RelaxationTimesSTD',...
                 'RelaxationPeaksIndices','RelaxationPeaksAmplitudes','RelaxationPeaksAmplitudesSTD','RelaxationPeaksAmplitudesMean','ContractionTimes',...
                    'ContractionStartTimes','ContractionEndTimes','ContractionTimesMean','ContractionTimesSTD','ContractionPeaksIndices',...
                        'ContractionPeaksAmplitudes','ContractionPeaksAmplitudesSTD','ContractionPeaksAmplitudesMean','BeatIntervalTimes','BeatIntervalTimesMean',...
                            'BeatIntervalTimesSTD','BeatingFrequency_PerVideoLength','BeatingFrequency_BPM');    
       end
       

end



try

 A =  {'Frame rate(fps):';'Total number of frames:';'FWHM or what:';'Relaxation times mean(s):';'Relaxation times STD(s):';'Contraction times mean(s):';'Contraction times STD(s):';...
     'Beat to beat interval mean(s):';'Beat to beat interval STD(s):';strcat('Beating frequency (beats/',num2str(durationProcessed),'s video duration processed):');strcat('Beating frequency (beats per minute):');'Relaxation amplitudes mean(a.u.):';...
     'Relaxation amplitudes STD(a.u.):';'Contraction amplitudes mean(a.u.):';'Contraction amplitudes STD(a.u.):';...
     'Processed frame 1st:';'Processed frame Last:';'Base line drift correction (Y/N):';'Invert signal (Y/N):';'Moving average filter span:'};

 B =  [FrameRate,FramesTotalNumberInVideo,FWHMorElse,RelaxationTimesMean,RelaxationTimesSTD,ContractionTimesMean,ContractionTimesSTD,...
 BeatIntervalTimesMean,BeatIntervalTimesSTD,BeatingFrequency,BeatingFrequency_BPM,RelaxationPeaksAmplitudesMean,RelaxationPeaksAmplitudesSTD,ContractionPeaksAmplitudesMean,...
 ContractionPeaksAmplitudesSTD,FrameNrProcessedStart,FrameNrProcessedEnd,BaseLinDriftCorCh,InvertsignalCh,FilterVal]';

    writematrix(DataX,strcat(PathName,'\',FileNameMAT(1:end-4),'_Raw.txt'),'Delimiter','tab');

        fid = fopen(strcat(PathName,'\',FileNameMAT(1:end-4),'_Results.txt'),'wt');
        for jj = 1 : 19
 %           fprintf( fid, '%s %d\n', A{jj}, B(jj) );
            fprintf( fid, '%s %.7f\n', A{jj}, B(jj) );

        end
        fprintf( fid, '%s %s\n','Measurement parameter:', SelectdDataIndicator);
        fclose( fid);
    imwrite(FirstFrameWithROI,strcat(PathName,'\',FileNameMAT(1:end-4),'_cell_&_area.jpg'));
    %imwrite(Final_plot,strcat(PathName,'\',FileNameMAT(1:end-4),'_signal.jpg'));
    imwrite(Final_plot_GUI,strcat(PathName,'\',FileNameMAT(1:end-4),'_GUI.jpg'));

  set(handles.MeasureBeatParameters,'enable','on');
 
end

elseif get(handles.SaveWithMeasure,'Value')==0
  set(handles.MeasureBeatParameters,'enable','on');

end

% --- Executes on button press in ignorePeaks.
function ignorePeaks_Callback(hObject, eventdata, handles)
global ignorePeaks ignoreValleys
ignorePeaks=get(handles.ignorePeaks,'Value');
%et(handles.ignoreValleys,'Value',0);
ignoreValleys=get(handles.ignoreValleys,'Value');


% --- Executes on button press in ignoreValleys.
function ignoreValleys_Callback(hObject, eventdata, handles)
global ignoreValleys ignorePeaks
ignoreValleys=get(handles.ignoreValleys,'Value');
%set(handles.ignorePeaks,'Value',0);
ignorePeaks=get(handles.ignorePeaks,'Value');


function VidLengthEndPercent_Callback(hObject, eventdata, handles)
% hObject    handle to VidLengthEndPercent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of VidLengthEndPercent as text
%        str2double(get(hObject,'String')) returns contents of VidLengthEndPercent as a double


% --- Executes during object creation, after setting all properties.
function VidLengthEndPercent_CreateFcn(hObject, eventdata, handles)
% hObject    handle to VidLengthEndPercent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function VidLengthStaPercent_Callback(hObject, eventdata, handles)
% hObject    handle to VidLengthStaPercent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of VidLengthStaPercent as text
%        str2double(get(hObject,'String')) returns contents of VidLengthStaPercent as a double


% --- Executes during object creation, after setting all properties.
function VidLengthStaPercent_CreateFcn(hObject, eventdata, handles)
% hObject    handle to VidLengthStaPercent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3


% --- Executes during object creation, after setting all properties.
function FilterSlider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FilterSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox4


% --- Executes on button press in checkbox5.
function checkbox5_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox5


% --- Executes on button press in checkbox7.
function checkbox7_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox7


% --- Executes on button press in checkbox8.
function checkbox8_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox8


% --- Executes on button press in checkbox9.
function checkbox9_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox9


% --- Executes on button press in checkbox10.
function checkbox10_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox10


% --- Executes on button press in checkbox11.
function checkbox11_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox11


% --- Executes on button press in Stopprocessing.
function Stopprocessing_Callback(hObject, eventdata, handles)
% hObject    handle to Stopprocessing (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ProcessOrNotState
ProcessOrNotState=0;
     set(handles.Processing,'String','Process','ForegroundColor','black','enable','on');       
     set(handles.Stopprocessing,'String','Stop process','ForegroundColor','black','enable','off');       


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in ProcessSelectedFileCheck.
function ProcessSelectedFileCheck_Callback(hObject, eventdata, handles)
% hObject    handle to ProcessSelectedFileCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of ProcessSelectedFileCheck


% --- Executes on slider movement.
function slider3_Callback(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in checkbox22.
function checkbox22_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox22


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1


% --- Executes on button press in ProcessStop.
function ProcessStop_Callback(hObject, eventdata, handles)
% hObject    handle to ProcessStop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ProcessOrNotState
ProcessOrNotState =0;
    set(handles.ProcessOneFile,'enable','on','string','Process select video','BackgroundColor',[0.83  0.82 0.78]);
    set(handles.ProcessStop,'enable','off','string','Stop Process','BackgroundColor',[0.83  0.82 0.78]);          
    


% --- Executes on selection change in ProcessOnefileOrAll_Files.
function ProcessOnefileOrAll_Files_Callback(hObject, eventdata, handles)
% hObject    handle to ProcessOnefileOrAll_Files (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns ProcessOnefileOrAll_Files contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ProcessOnefileOrAll_Files


% --- Executes during object creation, after setting all properties.
function ProcessOnefileOrAll_Files_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ProcessOnefileOrAll_Files (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function FWHM_or_what_Callback(hObject, eventdata, handles)
% hObject    handle to FWHM_or_what (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of FWHM_or_what as text
%        str2double(get(hObject,'String')) returns contents of FWHM_or_what as a double


% --- Executes during object creation, after setting all properties.
function FWHM_or_what_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FWHM_or_what (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function TolFacor_Callback(hObject, eventdata, handles)
% hObject    handle to TolFacor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of TolFacor as text
%        str2double(get(hObject,'String')) returns contents of TolFacor as a double


% --- Executes during object creation, after setting all properties.
function TolFacor_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TolFacor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ProcessAllFilesCheck.
function ProcessAllFilesCheck_Callback(hObject, eventdata, handles)


% --- Executes on selection change in SaveWithMeasure.
function SaveWithMeasure_Callback(hObject, eventdata, handles)
% hObject    handle to SaveWithMeasure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns SaveWithMeasure contents as cell array
%        contents{get(hObject,'Value')} returns selected item from SaveWithMeasure



function editFolderName_Callback(hObject, eventdata, handles)
% hObject    handle to editFolderName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editFolderName as text
%        str2double(get(hObject,'String')) returns contents of editFolderName as a double


% --- Executes during object creation, after setting all properties.
function editFolderName_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editFolderName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox3.
function listbox3_Callback(hObject, eventdata, handles)
% hObject    handle to listbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox3


% --- Executes during object creation, after setting all properties.
function listbox3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3
get(handles.radiobutton3,'Value')


% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton4


% --- Executes on slider movement.
function slider4_Callback(hObject, eventdata, handles)
% hObject    handle to slider4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

eas
% --- Executes on button press in pushbutton22.
function pushbutton22_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton23.
function pushbutton23_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on slider movement.
function sliderPeakWidth_Callback(hObject, eventdata, handles)
% hObject    handle to sliderPeakWidth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: 
%get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider





% --- Executes during object creation, after setting all properties.
function sliderPeakWidth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sliderPeakWidth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider6_Callback(hObject, eventdata, handles)
% hObject    handle to slider6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function PeakWidthMeanSlider1_Callback(hObject, eventdata, handles)
% hObject    handle to PeakWidthMeanSlider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function PeakWidthMeanSlider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PeakWidthMeanSlider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function PeakWidthMeanSlider2_Callback(hObject, eventdata, handles)
% hObject    handle to PeakWidthMeanSlider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function PeakWidthMeanSlider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PeakWidthMeanSlider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function pushbutton27_Callback(hObject, eventdata, handles)
% hObject    handle to PeakWidthMeanSlider1text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PeakWidthMeanSlider1text as text
%        str2double(get(hObject,'String')) returns contents of PeakWidthMeanSlider1text as a double



function userROIbox_Callback(hObject, eventdata, handles)
% hObject    handle to userROIbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of userROIbox as text
%        str2double(get(hObject,'String')) returns contents of userROIbox as a double



% --- Executes on button press in MovCentDet.
function MovCentDet_Callback(hObject, eventdata, handles)
% hObject    handle to MovCentDet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global time Line1ForMovCent Line2ForMovCent
    try
      %delete(Line1); delete(Line1);
    if exist('Line1ForMovCent')==1, delete(Line1ForMovCent); end
    if exist('Line2ForMovCent')==1, delete(Line2ForMovCent); end
    
    end
if get(handles.MovCentDet,'Value')==1
    try
                 Line1pos2=getPosition(Line1ForMovCent);
                 Line2pos2=getPosition(Line2ForMovCent);
    end


    Xlims=get(handles.axes2,'XLim');Ylims=get(handles.axes2,'YLim');
        Line1pos1=[Xlims(1) Ylims(1);Xlims(1) Ylims(2)];
        Line2pos1=[Xlims(2) Ylims(1);Xlims(2) Ylims(2)];

    if exist('Line1pos2')==1, Line1pos1=Line1pos2; end
    if exist('Line2pos2')==1, Line2pos1=Line2pos2; end
        Line2pos1(:,1)=Line2pos1(:,1)-0.4*Line2pos1(:,1);
        Line1ForMovCent = imline(handles.axes2,Line1pos1); %setColor(Line1ForMovCent,[0.49 0.18 0.56]);
        Line2ForMovCent = imline(handles.axes2,Line2pos1); %setColor(Line2ForMovCent,[0.49 0.18 0.56]);
          [~,Line1idx] = min(abs(Line1pos1(1)-time)); [~,Line2idx] = min(abs(Line2pos1(1)-time));
            xRange=Line1idx:Line2idx;
               % delete(Line1); delete(Line1);

else
    try
    %delete(Line1ForMovCent); delete(Line2ForMovCent);
    end
end




% --- Executes on button press in UserROI_in.
function UserROI_in_Callback(hObject, eventdata, handles)

global ROIProcessed ImrectCreateROIst xyloObj
          % delete(ImrectCreateROIst);
        test= (get(handles.userROIbox,'String'));
        num = textscan(test, '%f', 'Delimiter',',' );
        ROIProcessed = permute(num{1},[2,1]);
            [ROIProcessed]= minROIadjuster (ROIProcessed, xyloObj.Width, xyloObj.Height);
   
        try
           delete(ImrectCreateROIst);
           ImrectCreateROIst = drawrectangle(handles.axes1,'Position',ROIProcessed,'Color','g', 'FaceAlpha',0);
           ROIStr=mat2str(round(ROIProcessed));
           set(handles.userROIbox,'string',ROIStr(2:end-1));
        end
        ROICurrent=addlistener(ImrectCreateROIst,'MovingROI',@allevents);
        
        %   if get(handles.UserROI_in,'Value')==1
%         test= (get(handles.userROIbox,'String'));
%         num = textscan(test, '%f', 'Delimiter',',' );
%         ROIProcessed = permute(num{1},[2,1]);
%         if ROIProcessed(3) < 50 || ROIProcessed(3) < 50
%             ROIProcessed=[ROIProcessed(1:2)-round(75/2) 75 75];
%         end
%             
%         try
%             delete(ImrectCreateROIst);
%             ImrectCreateROIst = imrect(handles.axes1, ROIProcessed);  setColor(ImrectCreateROIst,'green');  
%         end
%     else
% 
%         %ROIProcessed=getPosition(ImrectCreateROIst);  
%         if ROIProcessed(3) < 50 || ROIProcessed(3) < 50
%             ROIProcessed=[ROIProcessed(1:2)-round(75/2) 75 75];
%         end
% 
%   end  


% % --- Executes on button press in GetROItoTextBox.
% function GetROItoTextBox_Callback(hObject, eventdata, handles)
% % hObject    handle to GetROItoTextBox (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% global ImrectCreateROIst
% %GetROItoTextBox
% ROIStr=mat2str(round(getPosition(ImrectCreateROIst)));
% %ROIStr=[161 121 151 123]
% set(handles.userROIbox,'string',ROIStr(2:end-1));
% %set(handles.ProcessOneFile,'enable','on','string','Process select video','BackgroundColor',[0.83  0.82 0.78]);


% --- Executes on button press in MovCentTextureDet.
function MovCentTextureDet_Callback(hObject, eventdata, handles)
% hObject    handle to MovCentTextureDet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- Executes when figure1 is resized.
function figure1_SizeChangedFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_1_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in AutoFcheck.
function AutoFcheck_Callback(hObject, eventdata, handles)
global AutoFcheckSt BaseLinDriftCorCh InvertsignalCh FilterVal
global Vx Vy d r s1 s2 time AutoComp ComponentForProcess

function [TextureCentX, TextureCentY]= MovementCenter_texture(vidFrame,ROIProcessed)
% Function created usign Heimo's script (speedtests.m)
% P = 'D:\hi_local\AUT_HeimoVapaaTutkija\BeatingAnalysis\VideoDataForHeimo\3rdRound\';
% vidObj = VideoReader([P '20170421_170619_01_36.3.avi']); 
%P = 'D:\hi_local\AUT_HeimoVapaaTutkija\BeatingAnalysis\VideoDataForHeimo\1stRound_differntClusters\';

%P = 'S:\71301_Laitos\Temporary\ModularMicroscopy\VideoDataForHeimo\1stRound_differntClusters\';
%vidObj = VideoReader([P '20180216_231602_01_37.00.avi']); 

% start from beginning
%vidObj.CurrentTime = 0; 



% read and view one frame
% Create figure and axes for visualization
%figure(1); currAxes = axes; axis image
%vidFrame = readFrame(vidObj);
%vidFrame=imcrop(vidFrame,[  246.4640   85.3946  110.2314  113.5219]);

%image(vidFrame, 'Parent', currAxes); axis image; title('First image as is')
I = single(vidFrame(:,:,1));% I = int16(vidFrame(:,:,1));
% Mi = max(I(:)); mi = min(I(:)); di = double((I-mi)/(Mi-mi)); Iim = cat(3, di, di, di);
% figure; im = image(Iim); axis image
%figure('colormap', gray(256)); imI = imagesc(I); axis image; colorbar; title('First image graylevel scaled')



% Gamma correction
%figure; histogram(I(:));
J = imadjust(vidFrame,[],[],0.5); %figure; histogram(J(:));
K = single(J(:,:,1)); 
%figure; histogram(K(:));
I = K;
%figure('colormap', gray(256)); imI = imagesc(I); axis image; colorbar; title('First image gamma gray scaled')


% filtering using integralImage
% S = filtsum2(ns, ns, I)/ns^2;
%tic
ns = 5; padSize = ([ns ns]-1)/2; Ipad = padarray(I, padSize, 'replicate','both'); % ns = 3;
% figure('colormap', gray(256)); impad = imagesc(Ipad); axis image; colorbar; title('Padded image')

intI = integralImage(Ipad); S = integralBoxFilter(intI, ns);
Is = I - S; %miS = min(S(:)); maS = max(S(:)); I2 = Is.^2;

%toc
%figure('colormap', gray(256)); ims = imagesc(S); axis image; colorbar; title('Smoothed image')
%figure('colormap', gray(256)); imIs = imagesc(Is); axis image; colorbar; title('Image minus smoothed')
%figure('colormap', gray(256)); imI2 = imagesc(I2); axis image; colorbar; title('(Image minus smoothed)^2')
%Ia = abs(Is);
Ia = abs(Is);
%figa = figure('colormap', gray(256)); 

%imabs = imagesc(Ia); 
%axis image; colorbar; title('Abs image minus smoothed')
%axab = gca;

%tt=1000

% convolution of image using large template-area of ones
%tic
mr = 50; ms = 2*mr+1; padSize = ([ms ms]-1)/2; Ipad = padarray(Ia, padSize);
intI = integralImage(Ipad); S2 = integralBoxFilter(intI, ms);
[Ma,In] = max(S2(:)); [Irow, Icol] = ind2sub(size(S2),In); % centerpoint of 'optimum'-square
%toc
% S2 = filtsum2(ms, ms, I2, 'f')/ms^2;


%figure('colormap', gray(256)); imI2s = imagesc(S2); axis image; colorbar
%line('XData', Icol, 'YData', Irow, 'Color', 'red', 'Marker', 'o',  'MarkerSize', 10); % centerpoint
%line('XData', Icol, 'YData', Irow, 'Color', 'blue', 'Marker', 'square',  'MarkerSize', mr); % total size

TextureCentX=Icol+ROIProcessed(1);
TextureCentY=Irow+ROIProcessed(2);



% locating places for squares
% [NN, MM] = size(S2); S0 = S2; S0(1:mr, :) = 0; S0(:, 1:mr) = 0; S0(NN-mr+1:NN,:) = 0; S0(:,MM-mr+1:NN,:) = 0;
% 
% md = 60; % distance
% ms = 2*md+1; padSize = ([ms ms]-1)/2; Ipad = padarray(S0, padSize);
% figu = figure('colormap', gray(256)); imI2sc = imagesc(Ipad); axis image; colorbar
% 
% ind = [];
% for ii=1:6
%   [Ma,In] = max(S0(:)); [Irow, Icol] = ind2sub(size(S0),In); ind = [ind; Irow Icol]
%   % zeroing
%   S0(Irow-mr-md:Irow+mr+md, Icol-mr-md:Icol+mr+md) = 0;
%   figure(figu); imI2s = imagesc(S0); axis image; colorbar
%   pause(1)
% end

function [ProcessedData]=PostProcess(BaseLinDriftCorCh,InvertsignalCh,FilterVal,SelectdData)
if BaseLinDriftCorCh==1
        %Drift correction
        %https://se.mathworks.com/help/signal/examples/peak-analysis.html
        [p,s,mu] = polyfit((1:numel(SelectdData))',SelectdData,6);
        f_y=polyval(p,(1:numel(SelectdData))',[],mu);
        ProcessedData = SelectdData - f_y; % detrend data
        %SelectdDataForPeaks = abs(SelectdData - f_y); % doing peak detetion in + regime
        %data_bLdone = (SelectdData - f_y); % doing peak detetion in + regime        
else
        ProcessedData=SelectdData;
end

%InvertsignalCh=1;
if InvertsignalCh==1
        ProcessedData=max(ProcessedData)-ProcessedData; % inverting the signal  
        ProcessedData=ProcessedData-mean(ProcessedData); % seeting signal mean position to zero

else
        ProcessedData=ProcessedData;
end


%LpFi=(140/60)/60;% Normalized freqency, Max Poss BR/samp rate
%ProcessedData=lowpass(ProcessedData,LpFi);


if FilterVal > 1
ProcessedData=smooth(ProcessedData,FilterVal);
end

% avoidig spikes; signal values above 4 std s are avoided
%-------------------------------------------------------
xm = nanmean(ProcessedData);
xs = nanstd(ProcessedData);
%stM=3.5;
stM=15;

% ProcessedData(ProcessedData > xm+stM*xs) = NaN;
% ProcessedData(ProcessedData < -1*(xm+stM*xs)) = NaN;

ProcessedData(ProcessedData > xm+stM*xs) = 0;
ProcessedData(ProcessedData < -1*(xm+stM*xs)) = 0;
%-------------------------------------------------------


% Auto inversion. 
% checkng upstrokes
%dd=ProcessedData;
%    rngA=round(length(ProcessedData)*0.05):length(ProcessedData)-round(length(ProcessedData)*0.05); %avoided beginning & end point frames

try
xInU=ProcessedData;%(rngA);
xInU(xInU<0)=0;
xInU=normalize(xInU,'range',[0 1]);

xInD=ProcessedData;
xInD(xInD>0)=0; xInD=abs(xInD);
xInD=normalize(xInD,'range',[0 1]);
LEV = statelevels((xInU+xInD)./2);

[UpTimes,UpInitCross,UpFinalCross] = pulsewidth(xInU,1:length(xInU),'StateLevels',LEV,'MidPercentReferenceLevel',50,'Tolerance',15);               
[DnTimes,DnInitCross,DnFinalCross] = pulsewidth(xInD,1:length(xInD),'StateLevels',LEV,'MidPercentReferenceLevel',50,'Tolerance',15);               

[objUp,pUp,SUp] = fit([1:length(UpInitCross(1:end))]',UpInitCross(1:end),'Poly2');
[objDn,pDn,SDn] = fit([1:length(DnInitCross(1:end))]',DnInitCross(1:end),'Poly2');

pUpy=objUp(1:round((length(UpInitCross)+length(DnInitCross))/2));
pDny=objDn(1:round((length(UpInitCross)+length(DnInitCross))/2));

Diff=pUpy-pDny;
    DiffChe=length(find(Diff>0))-length(find(Diff<0));

if DiffChe <= 0
     ProcessedData=max(ProcessedData)-ProcessedData; % inverting the signal  
     ProcessedData=ProcessedData-mean(ProcessedData); % seeting signal mean position to zero
else
     ProcessedData=ProcessedData;
end
catch
    % ProcessedData=ProcessedData;

end
    

%InvertsignalCh=1;
if InvertsignalCh==1
        ProcessedData=max(ProcessedData)-ProcessedData; % inverting the signal  
        ProcessedData=ProcessedData-mean(ProcessedData); % seeting signal mean position to zero

else
        ProcessedData=ProcessedData;
end


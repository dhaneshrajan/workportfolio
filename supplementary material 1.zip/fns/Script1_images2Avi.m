%
clear all; clc; close all
folder='C:\Users\tunnus\Documents\images';
imageFormat = 'png' ; % enter file format here
FrameRate=55; % Enter required frame rate

imageNames = dir(fullfile(folder,['*.',imageFormat]));
    NewAviVideoName=strcat(folder,'\','Movie.avi');

    imageNames = {imageNames.name}';
    outputVideo = VideoWriter(NewAviVideoName);
    outputVideo.FrameRate = FrameRate;
    open(outputVideo)
    tic
    for ii = 1:length(imageNames)
        img = imread(fullfile(folder,imageNames{ii}));
        writeVideo(outputVideo,img)
        disp(['processing: ',num2str(round(100*ii/length(imageNames))),' %'])
    end
close(outputVideo)
disp(['Completed: ',num2str(toc),' s'])


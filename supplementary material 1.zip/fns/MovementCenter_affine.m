function [AFOFMovCentreOut,spR,spC,AFOFVy,IndicesFull]=MovementCenter_affine(im1,im2,ROIProcessed) %Split the image into n x n matrix.....................

       [hM, wM] = size(im1);
        RDiv=4;  
        CDiv=4;
        

ColSegments=fix(ones(1,CDiv)*wM/CDiv);  
RawSegments=fix(ones(1,RDiv)*hM/RDiv);  

% figure, imshow(im1)
im1=imcrop(im1,[0,0,sum(ColSegments),sum(RawSegments)]); % cropping to have exact multiplier of Cdiv
im2=imcrop(im2,[0,0,sum(ColSegments),sum(RawSegments)]); % cropping to have exact multiplier of Cdiv
% figure, imshow(im1)

im1Split = mat2cell(im1, RawSegments, ColSegments)'; %splitting into Rdiv pieces
im2Split = mat2cell(im2, RawSegments, ColSegments)'; %splitting into Cdiv pieces

% figure, imshow(im1)
% figure
% for i=1:RDiv*CDiv
%     subplot(RDiv,CDiv,i), imshow(im1Split{i} )
% end

% 
          [spR,spC]=size(im1Split{1});
%             im1SplitXind=(spC/2):spC:wM; % indices of centre points of each segment
%                 %im1SplitXind = repmat(im1SplitXind,1,CDiv); % repeating for  16 elements
% 
%             im1SplitYind=(spR/2):spR:hM;
%                 %im1SplitYind = repmat(im1SplitYind,1,RDiv); % repeating for  16 elements
 

                
           im1SplitXind= 0:spC:spC*(CDiv-1);
           im1SplitYind= 0:spR:spR*(RDiv-1);              
                
 
AFOFMovCentreOut=[];

ii=1;
AFOF=[];
IndicesFull=[];

for RawNr=1:RDiv
 for ColNr=1:CDiv
     
    img1=im1Split{ii};
    img1=imresize(img1,10, 'nearest'); 

    img2=im2Split{ii};
    img2=imresize(img2,10, 'nearest');

    af1 = affine_flow('image1', img1, 'image2', img2, 'sigmaXY', 5, 'sampleStep',5);  af1 = af1.findFlow; 
    flow1 = af1.flowStruct;
        AFOF=[AFOF; flow1.vx0 flow1.vy0 flow1.d flow1.r flow1.s1 flow1.s2]; % mat for all segments
        IndicesFull=[IndicesFull; im1SplitXind(ColNr) im1SplitYind(RawNr)]; % x,y indices of centre points of each segment in RawNr x ColNr

    ii=ii+1;
 end
end

AFOFVy=AFOF(:,2);
%AFOFMovCentreOut=AFOF;
%AFOF

AFOF=abs(AFOF);
     [MaxVx,LinVx]=max(AFOF(:,1)); % mat for max movement flow vector and its linear index (in RDiv x CDiv matrix)
     [MaxVy,LinVy]=max(AFOF(:,2));
     [Maxd,Lind]=max(AFOF(:,3));
     [Maxr,Linr]=max(AFOF(:,4));
     [Maxs1,Lins1]=max(AFOF(:,5));
     [Maxs2,Lins2]=max(AFOF(:,6));
     
     %LinVy=16
     %LinVy=11
     InVx=IndicesFull(LinVx,[1 2]);% indices of beating centre in big 4x4 image
     InVy=IndicesFull(LinVy,[1 2]);
     Ind=IndicesFull(Lind,[1 2]); 
     Inr=IndicesFull(Linr,[1 2]); 
     Ins1=IndicesFull(Lins1,[1 2]); 
     Ins2=IndicesFull(Lins2,[1 2]); 

    AFOFMovCentreOut=[AFOFMovCentreOut; MaxVx InVx MaxVy InVy Maxd Ind Maxr Inr Maxs1 Ins1 Maxs2 Ins2];

    
    
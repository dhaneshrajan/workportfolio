clear all
close all
clc
im=imread('D:\files-files\Publications and research plans\thesis_PhD\figures\image.jpeg');
im=im(:,:,1);
imshow(im)

ROI=[0 0 150 200]
RawNr=1
ColNr=1



imrect(gca,ROI)

im1=imcrop(im,ROI);

       [hM, wM] = size(im1);
        RDiv=4;  
        CDiv=4;
        
ColSegments=fix(ones(1,CDiv)*wM/CDiv);  

RawSegments=fix(ones(1,RDiv)*hM/RDiv);  

im1=imcrop(im1,[0,0,sum(ColSegments),sum(RawSegments)]); % cropping to have exact multiplier of Cdiv

im1Split = mat2cell(im1, RawSegments, ColSegments)'; %splitting into Rdiv pieces

           %[spR,spC]=size(im);

          [spR,spC]=size(im1Split{1});
          
           im1SplitXind= 0:spC:spC*(CDiv-1)
           im1SplitYind= 0:spR:spR*(RDiv-1) 
% 
%      im1SplitXind(ColNr) 
%      im1SplitYind(RawNr)
     
      ROIn=[ROI(1)+im1SplitXind(ColNr) ROI(2)+im1SplitYind(RawNr),spC,spR]
      %
imrect(gca,ROIn);           
           
%imshow(im2)
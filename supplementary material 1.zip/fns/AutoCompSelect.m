function [SNRi,Fl6Str,AutoComp]=AutoCompSelect(Vx,Vy,d,r,s1,s2)

    rngV=round(length(Vx)*0.03):length(Vx)-round(length(Vx)*0.03); %avoided beginning & end point frames
    SNR=nanmean(abs([Vx(rngV) Vy(rngV) d(rngV) r(rngV) s1(rngV) s2(rngV)]))./nanstd(abs([Vx(rngV) Vy(rngV) d(rngV) r(rngV) s1(rngV) s2(rngV)])); % SNR
    [SNRv,SNRi] = sort(SNR,'descend');
    
    Fl6Data=[{Vx},{Vy},{d},{r},{s1},{s2}]; % six flow vectors
    Fl6Str=[{'VxCheck'},{'VyCheck'},{'DilationCheck'},{'RotationCheck'},{'ShearXCheck'},{'ShearDiagCheck'}];
    
    AutoComp=Fl6Data{SNRi(6)};


function [ROIProcessed]= minROIadjuster (ROIProcessed, imgWidth, imgHeight)

if ROIProcessed(3) < 78 
   ROIProcessed(3)= 78;
        if ROIProcessed(1) < 78
            ROIProcessed(1) = 1;
        elseif ROIProcessed(1) > (imgWidth -78)
            ROIProcessed(1) = (imgWidth -78);
        end
end


if ROIProcessed(4) < 78 
   ROIProcessed(4)= 78;
        if ROIProcessed(2) < 78
            ROIProcessed(2) = 1;
        elseif ROIProcessed(2) > (imgHeight -78)
            ROIProcessed(2) = (imgHeight -78);
        end
end

ROIProcessed=[ROIProcessed(1) ROIProcessed(2) ROIProcessed(3) ROIProcessed(4)];

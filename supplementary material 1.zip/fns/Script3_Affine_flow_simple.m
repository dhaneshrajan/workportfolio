clear, close all
% edit this part--------------------------------------------------------
addpath('C:\Users\tunnus\Documents\z.softwareVersion2Develop\softwareUpdate\software\fns'); 
%addpath to the folder where 'affine_flow.m is stored ie to [software\fns]

Folder='C:\Users\tunnus\Downloads';  % AVI folder
VidName='res-122-0e5-s011_matlab.avi'; % AVI name
% Edit ROI if required below
% edit this part--------------------------------------------------------


Obj=VideoReader([Folder,'/',VidName]); % create video obj
    Duration=Obj.Duration;  FrameRate= Obj.FrameRate;
    TotalFrames = FrameRate*Duration;  % total number of frames
    Obj.CurrentTime=0; figure(1), imshow(readFrame(Obj)); 
        %  Select Region of interest 
       ROI=[0 0 Obj.Width Obj.Height]; %  Full Frame
       % or 
       %ROI=getrect; % select ROI using mouse
       % or
       %ROI=[24  145  280  252]; 
       
%%
[Out] = []; 
   for i=1:TotalFrames
       if i==1 % Setting 1st frame as Reference frame
            Obj.CurrentTime=(i-1)/FrameRate;            
                  Ref = readFrame(Obj,'native'); % getting reference frame
            try
                  Ref=im2double(imcrop(Ref(:,:,1),ROI));          
            catch
                  Ref=Ref.cdata;
                  Ref=im2double(imcrop(Ref(:,:,1),ROI));  
            end            
       end     
   try
            Obj.CurrentTime=i/FrameRate;
                  Mes = readFrame(Obj,'native');  % Frame for measurement          
            try
                  Mes=im2double(imcrop(Mes(:,:,1),ROI));          
            catch
                  Mes=Mes.cdata;
                  Mes=im2double(imcrop(Mes(:,:,1),ROI));  
            end            
   end
        af = affine_flow('image1', Ref, 'image2', Mes, 'sigmaXY', 12, 'sampleStep',12);
        % sigmaXY -Smoothing constant for rectilinear sampling
        % A non-negative real scalar; default 0. The parameter for the
        % Gaussian mask used to smooth the images for gradient estimation.
        
        %sampleStep
        % A positive integer; default 1. The system of equations that is
        % solved is heavily overdetermined and it is not generally
        % necessary to use gradients for every pixel for the least-squares
        % solution. Gradients can theRefore be sampled on a grid with a
        % spacing of sampleStep pixels in x and y. The sampling is done
        % after smoothing. It is usually reasonable to set sampleStep
        % roughly equal to sigmaXY.
        af = af.findFlow;  flow = af.flowStruct;   
            Out(i,:)=[(i-1)./FrameRate flow.vx0 flow.vx0 flow.d flow.r flow.s1 flow.s2];            
        display(['Processed: ', num2str(100*i/TotalFrames),'%'])
   end
   
% Ploting  
figure(2), cla
str=[{'Vx'},{'Vy'},{'d'},{'r'},{'s1'},{'s2'}]; % plot title strings
Out(:,2:end)=Out(:,2:end)-mean(Out(:,2:end)); % seeting signal mean position to zero
    for n=1:6, subplot(2,3,n)
        plot(Out(:,1),Out(:,1+n)), title(str{n}), hold on
    end
% Use any good peak finder function to compute the number of peaks (beating
% rate) and peak widths (contraction times)
%
clear all; clc; close all
folder='F:\Disheet_Drug_Response\2nd';
VideoName='151212_03810.lqt2a_P12D18_D12_BL_DSh_E_re.avi';  % [mp4, mkv, mov, m4v, webm, wmv]
    
    v=VideoReader(strcat(folder,'\',VideoName));    
    NewAviVideoName=strcat(folder,'\',VideoName(1:end-4),'_matlab.avi');

writeObj = VideoWriter(NewAviVideoName);
writeObj.FrameRate = v.FrameRate;
open(writeObj);
currAxes = axes;
TotFrames=(v.Duration*v.FrameRate);

tic
while hasFrame(v)
    vidFrame = readFrame(v);
    image(vidFrame, 'Parent', currAxes);
    currAxes.Visible = 'off';
    writeVideo(writeObj,im2uint8(vidFrame)); % uint16 to unit8 conversion
    disp(['processing :',num2str(round(100*v.CurrentTime/v.Duration)),' %'])
    
end

close(writeObj);
disp('Completed')

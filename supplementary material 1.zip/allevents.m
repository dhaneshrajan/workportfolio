function allevents(src,evt)

 global ROIbox ROIProcessed
 evname = evt.EventName;
                switch(evname)
                    case{'MovingROI'}
            %             disp(['ROI moving Previous Position: ' mat2str(evt.PreviousPosition)]);
            %             disp(['ROI moving Current Position: ' mat2str(evt.CurrentPosition)]);
                       ROICurrent= evt.CurrentPosition;
                    case{'ROIMoved'}
            %             disp(['ROI moved Previous Position: ' mat2str(evt.PreviousPosition)]);
            %             disp(['ROI moved Current Position: ' mat2str(evt.CurrentPosition)]);
                       ROICurrent=evt.CurrentPosition;
                end
                
                        ROIProcessed=round(ROICurrent);
                        ROIStr=mat2str(ROIProcessed);
                       set(ROIbox,'string',ROIStr(2:end-1));
                       %set(handles.userROIbox,'string',ROIStr(2:end-1));
%                         ROITxt=round(ROICurrent);
%                         writematrix(ROITxt,strcat(pwd,'\test.txt'),'Delimiter','tab');
end 

